import random
import time


class AnimationManager:
    def __init__(self, root, config_manager):
        self.root = root
        self.config_manager = config_manager

        self.x = 0
        self.y = 0
        self.dx = 1
        self.dy = 1
        self.frozen = False
        self.speed_factor = 1.0
        self.dragging = False
        self.drag_data = {"x": 0, "y": 0}
        self.docked_to_taskbar = False

        self.pet_image = None

    def load_settings_from_config(self):
        self.frozen = self.config_manager.get("frozen", False)
        self.speed_factor = self.config_manager.get("speed_factor", 1.0)
        self.dx = self.config_manager.get("dx", random.choice([-2, -1, 1, 2]))
        self.dy = self.config_manager.get("dy", random.choice([-2, -1, 1, 2]))
        self.docked_to_taskbar = self.config_manager.get("docked_to_taskbar", False)

    def save_settings_to_config(self):
        self.config_manager.set("x", self.x)
        self.config_manager.set("y", self.y)
        self.config_manager.set("frozen", self.frozen)
        self.config_manager.set("speed_factor", self.speed_factor)
        self.config_manager.set("dx", self.dx)
        self.config_manager.set("dy", self.dy)
        self.config_manager.set("docked_to_taskbar", self.docked_to_taskbar)

    def set_pet_image(self, pet_image):
        self.pet_image = pet_image

    def set_initial_position(self):
        screen_width = self.root.winfo_screenwidth()
        screen_height = self.root.winfo_screenheight()

        saved_x = self.config_manager.get("x")
        saved_y = self.config_manager.get("y")

        if saved_x is not None and saved_y is not None:
            self.x = saved_x
            self.y = saved_y
        else:
            self.x = random.randint(0, screen_width - self.pet_image.width)
            self.y = random.randint(0, screen_height - self.pet_image.height)

        self.root.geometry(f"{self.pet_image.width}x{self.pet_image.height}+{int(self.x)}+{int(self.y)}")

    def on_press(self, event, toggle_dock_callback=None):
        self.dragging = True
        self.drag_data["x"] = event.x_root
        self.drag_data["y"] = event.y_root
        self.root.attributes('-topmost', True)

        if self.docked_to_taskbar and toggle_dock_callback:
            toggle_dock_callback()

    def on_drag(self, event):
        if self.dragging:
            screen_width = self.root.winfo_screenwidth()
            screen_height = self.root.winfo_screenheight()
            pet_width = self.pet_image.width
            pet_height = self.pet_image.height

            dx = event.x_root - self.drag_data["x"]
            dy = event.y_root - self.drag_data["y"]

            self.x += dx
            self.y += dy

            self.x = max(0, min(self.x, screen_width - pet_width))
            self.y = max(0, min(self.y, screen_height - pet_height))

            self.root.geometry(f"+{int(self.x)}+{int(self.y)}")
            self.drag_data["x"] = event.x_root
            self.drag_data["y"] = event.y_root

    def on_release(self, event):
        self.dragging = False
        if not self.frozen:
            self.dx = random.choice([-2, -1, 1, 2])
            self.dy = random.choice([-2, -1, 1, 2])
        self.save_settings_to_config()

    def toggle_freeze(self):
        self.frozen = not self.frozen
        if not self.frozen:
            self.dx = random.choice([-2, -1, 1, 2])
            self.dy = random.choice([-2, -1, 1, 2])
        self.save_settings_to_config()

    def adjust_speed(self, delta):
        self.speed_factor += delta
        self.speed_factor = max(0.2, min(self.speed_factor, 3.0))
        self.save_settings_to_config()

    def reset_speed(self):
        self.speed_factor = 1.0
        self.save_settings_to_config()

    def animate(self):
        if not self.dragging and not self.frozen and not self.docked_to_taskbar:
            self.x += self.dx * self.speed_factor
            self.y += self.dy * self.speed_factor

            screen_width = self.root.winfo_screenwidth()
            screen_height = self.root.winfo_screenheight()
            pet_width = self.pet_image.width
            pet_height = self.pet_image.height

            if self.x <= 0:
                self.x = 0
                self.dx = abs(self.dx)
            elif self.x >= screen_width - pet_width:
                self.x = screen_width - pet_width
                self.dx = -abs(self.dx)

            if self.y <= 0:
                self.y = 0
                self.dy = abs(self.dy)
            elif self.y >= screen_height - pet_height:
                self.y = screen_height - pet_height
                self.dy = -abs(self.dy)

            self.root.geometry(f"+{int(self.x)}+{int(self.y)}")

        self.root.after(30, self.animate)

    def special_animation(self):
        original_x = self.x

        for i in range(10):
            if i % 2 == 0:
                self.root.geometry(f"+{int(self.x + 5)}+{int(self.y)}")
            else:
                self.root.geometry(f"+{int(self.x - 5)}+{int(self.y)}")

            self.root.update()
            time.sleep(0.03)

        self.root.geometry(f"+{int(original_x)}+{int(self.y)}")
        self.x = original_x

    def animate_to_position(self, target_x, target_y):
        steps = 10
        current_x = self.x
        current_y = self.y

        for i in range(1, steps + 1):
            if not self.docked_to_taskbar:
                break

            new_x = current_x + (target_x - current_x) * i / steps
            new_y = current_y + (target_y - current_y) * i / steps

            self.x = new_x
            self.y = new_y
            self.root.geometry(f"+{int(new_x)}+{int(new_y)}")

            time.sleep(0.02)
            self.root.update()

    def set_docked_state(self, docked):
        self.docked_to_taskbar = docked
        if docked:
            self.frozen = True
        self.save_settings_to_config()

    def update_position_for_size_change(self, old_width, old_height, new_width, new_height):
        old_center_x = self.x + old_width // 2
        old_center_y = self.y + old_height // 2

        self.x = old_center_x - new_width // 2
        self.y = old_center_y - new_height // 2

        screen_width = self.root.winfo_screenwidth()
        screen_height = self.root.winfo_screenheight()
        self.x = max(0, min(self.x, screen_width - new_width))
        self.y = max(0, min(self.y, screen_height - new_height))

        self.root.geometry(f"{new_width}x{new_height}+{int(self.x)}+{int(self.y)}")

    def get_position(self):
        return self.x, self.y

    def set_position(self, x, y):
        self.x = x
        self.y = y
        self.root.geometry(f"+{int(self.x)}+{int(self.y)}")

    def is_frozen(self):
        return self.frozen

    def get_speed_factor(self):
        return self.speed_factor

    def is_docked_to_taskbar(self):
        return self.docked_to_taskbar