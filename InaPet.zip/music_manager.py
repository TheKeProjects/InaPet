import os
import pygame
import time
import threading
from tkinter import messagebox as tk_messagebox


class MusicManager:
    def __init__(self, config_manager, get_base_path_func, update_context_menu_func=None):
        self.config_manager = config_manager
        self.get_base_path = get_base_path_func
        self.update_context_menu = update_context_menu_func

        self.music_enabled = False
        self.music_paused = False
        self.music_loop_mode = False
        self.use_custom_playlist = False
        self.current_song = None
        self.playlist = []
        self.current_song_index = 0
        self.custom_playlist = []
        self.music_volume = 0.5

        pygame.mixer.init()
        pygame.mixer.music.set_volume(self.music_volume)

    def load_settings_from_config(self):
        self.music_enabled = self.config_manager.get("music_enabled", False)
        self.music_paused = self.config_manager.get("music_paused", False)
        self.music_loop_mode = self.config_manager.get("music_loop_mode", False)
        self.use_custom_playlist = self.config_manager.get("use_custom_playlist", False)
        self.custom_playlist = self.config_manager.get("custom_playlist", [])
        self.music_volume = self.config_manager.get("music_volume", 0.5)
        self.current_song_index = self.config_manager.get("current_song_index", 0)
        pygame.mixer.music.set_volume(self.music_volume)

    def save_settings_to_config(self):
        self.config_manager.set("music_enabled", self.music_enabled)
        self.config_manager.set("music_paused", self.music_paused)
        self.config_manager.set("music_loop_mode", self.music_loop_mode)
        self.config_manager.set("use_custom_playlist", self.use_custom_playlist)
        self.config_manager.set("custom_playlist", self.custom_playlist)
        self.config_manager.set("music_volume", self.music_volume)
        self.config_manager.set("current_song_index", self.current_song_index)

    def setup_music(self):
        music_dir = os.path.join(self.get_base_path(), "musica")
        self.playlist = []

        if os.path.exists(music_dir):
            for root, _, files in os.walk(music_dir):
                for file in files:
                    full_path = os.path.join(root, file)
                    if os.path.isfile(full_path) and file.lower().endswith(('.mp3', '.wav', '.ogg')):
                        self.playlist.append(full_path)

    def toggle_music(self):
        self.music_enabled = not self.music_enabled

        if self.music_enabled:
            if not self.playlist and not self.custom_playlist:
                self.setup_music()

            if self.playlist or self.custom_playlist:
                self.current_song_index = 0
                self.play_next_song()
            else:
                self.music_enabled = False
                tk_messagebox.showinfo("🎵 Música", "🚫 No hay canciones en la carpeta 'musica'")
        else:
            pygame.mixer.music.stop()

        if self.update_context_menu:
            self.update_context_menu()
        self.save_settings_to_config()

    def toggle_music_pause(self):
        if not self.music_enabled:
            return

        self.music_paused = not self.music_paused

        if self.music_paused:
            pygame.mixer.music.pause()
        else:
            pygame.mixer.music.unpause()

        if self.update_context_menu:
            self.update_context_menu()
        self.save_settings_to_config()

    def change_loop_mode(self):
        self.music_loop_mode = not self.music_loop_mode
        if self.update_context_menu:
            self.update_context_menu()
        self.save_settings_to_config()

    def toggle_custom_playlist(self):
        self.use_custom_playlist = not self.use_custom_playlist
        self.current_song_index = 0
        if self.update_context_menu:
            self.update_context_menu()
        self.save_settings_to_config()

        if self.music_enabled and not self.music_paused:
            pygame.mixer.music.stop()
            self.play_next_song()

    def adjust_volume(self, delta):
        self.music_volume = max(0.0, min(1.0, self.music_volume + delta))
        pygame.mixer.music.set_volume(self.music_volume)
        if self.update_context_menu:
            self.update_context_menu()
        self.save_settings_to_config()

    def prev_song(self):
        if not self.music_enabled or not (self.playlist or self.custom_playlist):
            return

        playlist = self.custom_playlist if self.use_custom_playlist and self.custom_playlist else self.playlist

        if not playlist:
            return

        self.current_song_index = (self.current_song_index - 1) % len(playlist)
        song_path = playlist[self.current_song_index]

        try:
            pygame.mixer.music.load(song_path)
            pygame.mixer.music.play()
            pygame.mixer.music.set_volume(self.music_volume)
            self.current_song = song_path
        except Exception as e:
            print(f"Error al reproducir canción: {e}")

    def play_next_song(self):
        if not self.music_enabled or self.music_paused:
            return

        if self.use_custom_playlist and self.custom_playlist:
            playlist = self.custom_playlist
        else:
            playlist = self.playlist

        if not playlist:
            self.music_enabled = False
            if self.update_context_menu:
                self.update_context_menu()
            return

        if self.music_loop_mode and self.current_song:
            song_path = self.current_song
        else:
            song_path = playlist[self.current_song_index]
            self.current_song_index = (self.current_song_index + 1) % len(playlist)

        try:
            pygame.mixer.music.load(song_path)
            pygame.mixer.music.play()
            pygame.mixer.music.set_volume(self.music_volume)
            self.current_song = song_path

            if not self.music_loop_mode:
                threading.Thread(target=self.wait_for_song_end, daemon=True).start()
        except Exception as e:
            print(f"Error al reproducir canción: {e}")
            self.current_song_index = (self.current_song_index + 1) % len(playlist)
            self.play_next_song()

    def wait_for_song_end(self):
        while pygame.mixer.music.get_busy():
            time.sleep(0.5)

        if self.music_enabled and not self.music_paused:
            self.play_next_song()

    def get_all_songs(self):
        all_songs = []
        music_dir = os.path.join(self.get_base_path(), "musica")
        if os.path.exists(music_dir):
            for root, _, files in os.walk(music_dir):
                for file in files:
                    full_path = os.path.join(root, file)
                    if os.path.isfile(full_path) and file.lower().endswith(('.mp3', '.wav', '.ogg')):
                        all_songs.append(full_path)
        return all_songs

    def update_custom_playlist(self, new_playlist):
        self.custom_playlist = new_playlist
        self.current_song_index = 0
        self.save_settings_to_config()

        if self.music_enabled and self.use_custom_playlist:
            pygame.mixer.music.stop()
            self.play_next_song()

    def quit(self):
        pygame.mixer.quit()