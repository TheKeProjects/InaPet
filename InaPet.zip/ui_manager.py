import tkinter as tk
from PIL import Image, ImageTk, ImageDraw, ImageFont
import os


class UIManager:
    def __init__(self, root, skin_manager, music_manager, config_manager):
        self.root = root
        self.skin_manager = skin_manager
        self.music_manager = music_manager
        self.config_manager = config_manager
        self.context_menu = None
        self.last_menu_x = 0
        self.last_menu_y = 0

    def create_emoji_image(self, emoji_text, size=24):
        try:
            img_size = size + 8
            img = Image.new("RGBA", (img_size, img_size), (255, 255, 255, 0))
            draw = ImageDraw.Draw(img)

            try:
                font_paths = [
                    "C:/Windows/Fonts/seguiemj.ttf",
                    "C:/Windows/Fonts/segoeuiemoji.ttf",
                    "C:/Windows/Fonts/seguiemj.ttf",
                ]

                font = None
                for font_path in font_paths:
                    try:
                        font = ImageFont.truetype(font_path, size)
                        break
                    except:
                        continue

                if font is None:
                    font = ImageFont.load_default()
            except:
                font = ImageFont.load_default()

            bbox = draw.textbbox((0, 0), emoji_text, font=font)
            text_width = bbox[2] - bbox[0]
            text_height = bbox[3] - bbox[1]

            x = (img_size - text_width) // 2 - bbox[0]
            y = (img_size - text_height) // 2 - bbox[1]

            draw.text((x, y), emoji_text, font=font, fill=(0, 0, 0, 255), embedded_color=True)

            if img_size != size:
                img = img.resize((size, size), Image.LANCZOS)

            return ImageTk.PhotoImage(img)

        except Exception as e:
            print(f"Error creando emoji {emoji_text}: {e}")
            img = Image.new("RGBA", (size, size), (255, 255, 255, 0))
            return ImageTk.PhotoImage(img)

    def create_context_menu(self, x, y, callbacks):
        if self.context_menu:
            self.context_menu.destroy()

        self.context_menu = tk.Menu(self.root, tearoff=0)
        self.last_menu_x = x
        self.last_menu_y = y

        pause_emoji = self.create_emoji_image("🔴", 20)
        play_emoji = self.create_emoji_image("🟢", 20)
        minimize_emoji = self.create_emoji_image("📱", 20)
        dock_emoji = self.create_emoji_image("📌", 20)
        undock_emoji = self.create_emoji_image("🔓", 20)
        suggestion_emoji = self.create_emoji_image("💡", 20)

        frozen = callbacks.get('is_frozen', lambda: False)()
        auto_open_paused = callbacks.get('is_auto_open_paused', lambda: False)()
        docked_to_taskbar = callbacks.get('is_docked_to_taskbar', lambda: False)()
        use_japanese_names = callbacks.get('is_using_japanese_names', lambda: False)()

        if not frozen:
            self.context_menu.add_command(label="Pausar", image=pause_emoji, compound=tk.LEFT, command=callbacks.get('toggle_freeze'))
        else:
            self.context_menu.add_command(label="Reanudar", image=play_emoji, compound=tk.LEFT, command=callbacks.get('toggle_freeze'))

        if not auto_open_paused:
            self.context_menu.add_command(label="Pausar popups", image=pause_emoji, compound=tk.LEFT, command=callbacks.get('toggle_auto_open_pause'))
        else:
            self.context_menu.add_command(label="Reanudar popups", image=play_emoji, compound=tk.LEFT, command=callbacks.get('toggle_auto_open_pause'))

        if not docked_to_taskbar:
            self.context_menu.add_command(label="Anclar a barra de tareas", image=dock_emoji, compound=tk.LEFT, command=callbacks.get('toggle_dock_to_taskbar'))
        else:
            self.context_menu.add_command(label="Desanclar de barra de tareas", image=undock_emoji, compound=tk.LEFT, command=callbacks.get('toggle_dock_to_taskbar'))

        name_emoji = self.create_emoji_image("🇯🇵", 20)
        if use_japanese_names:
            self.context_menu.add_command(label="Nombres: Japoneses", image=name_emoji, compound=tk.LEFT, command=callbacks.get('toggle_name_mode'))
        else:
            self.context_menu.add_command(label="Nombres: Europeos", image=name_emoji, compound=tk.LEFT, command=callbacks.get('toggle_name_mode'))

        self._add_skin_menu(callbacks)
        self.context_menu.add_separator()
        self._add_speed_size_menus(callbacks)
        self._add_options_menu(callbacks)
        self._add_music_menu(callbacks)

        self.context_menu.add_separator()
        self.context_menu.add_command(label="Solicitudes", image=suggestion_emoji, compound=tk.LEFT, command=callbacks.get('show_suggestion_dialog'))
        self.context_menu.add_command(label="Minimizar", image=minimize_emoji, compound=tk.LEFT, command=callbacks.get('minimize_to_tray'))

        exit_emoji = self.create_emoji_image("❌", 20)
        self.context_menu.add_command(label="Salir", image=exit_emoji, compound=tk.LEFT, command=callbacks.get('quit_app'))

        self.context_menu.post(x, y)

    def _add_skin_menu(self, callbacks):
        if self.skin_manager.skin_categories:
            skin_menu = tk.Menu(self.context_menu, tearoff=0)
            skin_emoji = self.create_emoji_image("🎭", 20)

            for category, structure in self.skin_manager.skin_categories.items():
                category_menu = tk.Menu(skin_menu, tearoff=0)
                category_logo = self.skin_manager.folder_logos.get(category)
                display_category = self.skin_manager.get_display_folder_name(category)

                def add_menu_items(menu, structure):
                    if 'files' in structure:
                        for file_name, file_path in structure['files']:
                            display_name = self.skin_manager.get_display_name(file_name)

                            try:
                                thumb_img = Image.open(file_path)
                                thumb_img.thumbnail((32, 32), Image.LANCZOS)
                                thumb_photo = ImageTk.PhotoImage(thumb_img)

                                menu.add_command(
                                    label=display_name,
                                    image=thumb_photo,
                                    compound=tk.LEFT,
                                    command=lambda p=file_path: callbacks.get('change_skin')(p)
                                )

                                if not hasattr(menu, 'thumbnails'):
                                    menu.thumbnails = []
                                menu.thumbnails.append(thumb_photo)
                            except Exception as e:
                                print(f"Error al cargar miniatura: {e}")
                                menu.add_command(
                                    label=display_name,
                                    command=lambda p=file_path: callbacks.get('change_skin')(p)
                                )

                    for folder_name, substructure in structure.items():
                        if folder_name != 'files':
                            submenu = tk.Menu(menu, tearoff=0)
                            folder_logo = self.skin_manager.folder_logos.get(folder_name)
                            add_menu_items(submenu, substructure)
                            display_folder = self.skin_manager.get_display_folder_name(folder_name)

                            if folder_logo:
                                menu.add_cascade(label=display_folder, menu=submenu, image=folder_logo, compound=tk.LEFT)
                                if not hasattr(menu, 'subfolder_logos'):
                                    menu.subfolder_logos = []
                                menu.subfolder_logos.append(folder_logo)
                            else:
                                menu.add_cascade(label=display_folder, menu=submenu)

                add_menu_items(category_menu, structure)

                if category_logo:
                    skin_menu.add_cascade(label=display_category, menu=category_menu, image=category_logo, compound=tk.LEFT)
                else:
                    skin_menu.add_cascade(label=display_category, menu=category_menu)

            self.context_menu.add_cascade(label="Skins", menu=skin_menu, image=skin_emoji, compound=tk.LEFT)
        # Keep reference to prevent garbage collection
        if not hasattr(self.context_menu, 'emoji_references'):
            self.context_menu.emoji_references = []
            self.context_menu.emoji_references.append(skin_emoji)
        else:
            no_skin_emoji = self.create_emoji_image("❌", 20)
            self.context_menu.add_command(label="No hay skins disponibles", image=no_skin_emoji, compound=tk.LEFT, state=tk.DISABLED)

    def _add_speed_size_menus(self, callbacks):
        speed_emoji = self.create_emoji_image("⚡", 20)
        size_emoji = self.create_emoji_image("📏", 20)
        slower_emoji = self.create_emoji_image("➖", 20)
        faster_emoji = self.create_emoji_image("➕", 20)
        reset_emoji = self.create_emoji_image("🟢", 20)

        speed_factor = callbacks.get('get_speed_factor', lambda: 1.0)()
        size_factor = callbacks.get('get_size_factor', lambda: 1.0)()

        speed_menu = tk.Menu(self.context_menu, tearoff=0)
        speed_menu.add_command(label="Más lento", image=slower_emoji, compound=tk.LEFT, command=lambda: callbacks.get('adjust_speed')(-0.2))
        speed_menu.add_command(label="Normal", image=reset_emoji, compound=tk.LEFT, command=callbacks.get('reset_speed'))
        speed_menu.add_command(label="Más rápido", image=faster_emoji, compound=tk.LEFT, command=lambda: callbacks.get('adjust_speed')(0.2))
        self.context_menu.add_cascade(label=f"Velocidad: {speed_factor:.1f}x", menu=speed_menu, image=speed_emoji, compound=tk.LEFT)
        # Keep reference to prevent garbage collection
        if not hasattr(self.context_menu, 'emoji_references'):
            self.context_menu.emoji_references = []
        self.context_menu.emoji_references.extend([speed_emoji, slower_emoji, faster_emoji, reset_emoji])

        size_menu = tk.Menu(self.context_menu, tearoff=0)
        size_menu.add_command(label="Más pequeño", image=slower_emoji, compound=tk.LEFT, command=lambda: callbacks.get('adjust_size')(-0.1))
        size_menu.add_command(label="Tamaño normal", image=reset_emoji, compound=tk.LEFT, command=callbacks.get('reset_size'))
        size_menu.add_command(label="Más grande", image=faster_emoji, compound=tk.LEFT, command=lambda: callbacks.get('adjust_size')(0.1))
        self.context_menu.add_cascade(label=f"Tamaño: {size_factor:.1f}x", menu=size_menu, image=size_emoji, compound=tk.LEFT)
        # Keep reference to prevent garbage collection
        self.context_menu.emoji_references.append(size_emoji)

    def _add_options_menu(self, callbacks):
        startup_emoji = self.create_emoji_image("⏰", 20)
        check_emoji = self.create_emoji_image("✅", 20)
        update_emoji = self.create_emoji_image("🔄", 20)
        search_emoji = self.create_emoji_image("🔍", 20)

        startup_enabled = callbacks.get('is_startup_enabled', lambda: False)()
        update_available = callbacks.get('is_update_available', lambda: False)()

        if startup_enabled:
            self.context_menu.add_command(label="Abrir al inicio", image=check_emoji, compound=tk.LEFT, command=callbacks.get('toggle_startup_option'))
        else:
            self.context_menu.add_command(label="Abrir al inicio", image=startup_emoji, compound=tk.LEFT, command=callbacks.get('toggle_startup_option'))

        if update_available:
            self.context_menu.add_command(label="Actualización disponible!", image=update_emoji, compound=tk.LEFT, command=callbacks.get('check_updates_ui'))
        else:
            self.context_menu.add_command(label="Buscar actualizaciones", image=search_emoji, compound=tk.LEFT, command=callbacks.get('check_updates_ui'))

        # Keep reference to prevent garbage collection
        if not hasattr(self.context_menu, 'emoji_references'):
            self.context_menu.emoji_references = []
        self.context_menu.emoji_references.extend([startup_emoji, check_emoji, update_emoji, search_emoji])

    def _add_music_menu(self, callbacks):
        music_menu = tk.Menu(self.context_menu, tearoff=0)
        music_emoji = self.create_emoji_image("🎵", 20)

        if self.music_manager.music_enabled:
            music_state_emoji = self.create_emoji_image("✅", 20)
            music_menu.add_command(
                label=f"Música: Activada",
                image=music_state_emoji,
                compound=tk.LEFT,
                command=callbacks.get('toggle_music')
            )
        else:
            music_state_emoji = self.create_emoji_image("❌", 20)
            music_menu.add_command(
                label=f"Música: Desactivada",
                image=music_state_emoji,
                compound=tk.LEFT,
                command=callbacks.get('toggle_music')
            )

        if self.music_manager.music_enabled:
            if not self.music_manager.music_paused:
                pause_music_emoji = self.create_emoji_image("🔴", 20)
                music_menu.add_command(label="Pausar", image=pause_music_emoji, compound=tk.LEFT, command=callbacks.get('toggle_music_pause'))
            else:
                play_music_emoji = self.create_emoji_image("🟢", 20)
                music_menu.add_command(label="Reanudar", image=play_music_emoji, compound=tk.LEFT, command=callbacks.get('toggle_music_pause'))

            if self.music_manager.music_loop_mode:
                loop_emoji = self.create_emoji_image("🔂", 20)
                music_menu.add_command(label="Loop: Misma canción", image=loop_emoji, compound=tk.LEFT, command=callbacks.get('change_loop_mode'))
            else:
                playlist_emoji = self.create_emoji_image("📋", 20)
                music_menu.add_command(label="Loop: Lista secuencial", image=playlist_emoji, compound=tk.LEFT, command=callbacks.get('change_loop_mode'))

            vol_menu = tk.Menu(music_menu, tearoff=0)
            vol_up_emoji = self.create_emoji_image("➕", 20)
            vol_down_emoji = self.create_emoji_image("➖", 20)
            mute_emoji = self.create_emoji_image("🔇", 20)
            vol_menu.add_command(label="Subir volumen", image=vol_up_emoji, compound=tk.LEFT, command=lambda: callbacks.get('adjust_volume')(0.1))
            vol_menu.add_command(label="Bajar volumen", image=vol_down_emoji, compound=tk.LEFT, command=lambda: callbacks.get('adjust_volume')(-0.1))
            vol_menu.add_command(label="Silenciar", image=mute_emoji, compound=tk.LEFT, command=lambda: callbacks.get('adjust_volume')(-self.music_manager.music_volume))
            volume_emoji = self.create_emoji_image("🔊", 20)
            music_menu.add_cascade(label=f"Volumen: {int(self.music_manager.music_volume * 100)}%", menu=vol_menu, image=volume_emoji, compound=tk.LEFT)

            music_menu.add_separator()
            if self.music_manager.use_custom_playlist:
                custom_playlist_emoji = self.create_emoji_image("✅", 20)
                music_menu.add_command(label="Lista personal", image=custom_playlist_emoji, compound=tk.LEFT, command=callbacks.get('toggle_custom_playlist'))
            else:
                custom_playlist_emoji = self.create_emoji_image("📝", 20)
                music_menu.add_command(label="Lista personal", image=custom_playlist_emoji, compound=tk.LEFT, command=callbacks.get('toggle_custom_playlist'))

            edit_emoji = self.create_emoji_image("📋", 20)
            music_menu.add_command(label="Editar lista personal", image=edit_emoji, compound=tk.LEFT, command=callbacks.get('open_custom_playlist_editor'))

            music_menu.add_separator()
            prev_emoji = self.create_emoji_image("⏮", 20)
            next_emoji = self.create_emoji_image("⏭", 20)
            music_menu.add_command(label="Canción anterior", image=prev_emoji, compound=tk.LEFT, command=callbacks.get('prev_song'))
            music_menu.add_command(label="Canción siguiente", image=next_emoji, compound=tk.LEFT, command=callbacks.get('play_next_song'))

            if self.music_manager.current_song:
                music_menu.add_separator()
                current_song_emoji = self.create_emoji_image("🎶", 20)
                song_name = os.path.basename(self.music_manager.current_song)
                music_menu.add_command(label=f"Reproduciendo: {song_name}", image=current_song_emoji, compound=tk.LEFT, state=tk.DISABLED)

        self.context_menu.add_cascade(label="Música", menu=music_menu, image=music_emoji, compound=tk.LEFT)
        # Keep reference to prevent garbage collection
        if not hasattr(self.context_menu, 'emoji_references'):
            self.context_menu.emoji_references = []
        # Store all music-related emojis to prevent garbage collection
        music_emojis = [music_emoji, music_state_emoji]

        if self.music_manager.music_enabled:
            # Add volume control emojis
            music_emojis.extend([vol_up_emoji, vol_down_emoji, mute_emoji, volume_emoji,
                               edit_emoji, prev_emoji, next_emoji])

            if not self.music_manager.music_paused:
                music_emojis.append(pause_music_emoji)
            else:
                music_emojis.append(play_music_emoji)

            if self.music_manager.music_loop_mode:
                music_emojis.append(loop_emoji)
            else:
                music_emojis.append(playlist_emoji)

            music_emojis.append(custom_playlist_emoji)

            if self.music_manager.current_song:
                music_emojis.append(current_song_emoji)

        self.context_menu.emoji_references.extend(music_emojis)

    def update_context_menu(self, callbacks):
        if self.context_menu:
            self.context_menu.destroy()
            self.context_menu = None
            self.create_context_menu(self.last_menu_x, self.last_menu_y, callbacks)