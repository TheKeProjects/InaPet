import os
import sys
import random
import subprocess
from PIL import Image


class FileManager:
    def __init__(self, config_manager, get_base_path_func, special_animation_callback=None):
        self.config_manager = config_manager
        self.get_base_path = get_base_path_func
        self.special_animation_callback = special_animation_callback

        self.auto_open_paused = False
        self.auto_open_timer = None

    def load_settings_from_config(self):
        self.auto_open_paused = self.config_manager.get("auto_open_paused", False)

    def save_settings_to_config(self):
        self.config_manager.set("auto_open_paused", self.auto_open_paused)

    def create_required_folders(self):
        base_path = self.get_base_path()
        folders = ["imagenes", "notas", "musica", "logos"]

        for folder in folders:
            folder_path = os.path.join(base_path, folder)
            if not os.path.exists(folder_path):
                os.makedirs(folder_path)
                if folder == "notas":
                    with open(os.path.join(folder_path, "ejemplo.txt"), "w") as f:
                        f.write("¡Esta es una nota de ejemplo!\nGuarda aquí tus notas importantes.")
                elif folder == "imagenes":
                    img = Image.new('RGB', (100, 100), color=(73, 109, 137))
                    img.save(os.path.join(folder_path, "ejemplo.png"))

    def schedule_auto_open(self, root):
        if self.auto_open_timer:
            root.after_cancel(self.auto_open_timer)
            self.auto_open_timer = None

        if not self.auto_open_paused:
            interval = random.randint(30000, 300000)
            self.auto_open_timer = root.after(interval, lambda: self.auto_open_file(root))

    def auto_open_file(self, root):
        if self.auto_open_paused:
            self.schedule_auto_open(root)
            return

        try:
            files_dir = os.path.join(self.get_base_path(), "imagenes")
            notes_dir = os.path.join(self.get_base_path(), "notas")
            files = []

            if os.path.exists(files_dir):
                for file in os.listdir(files_dir):
                    full_path = os.path.join(files_dir, file)
                    if os.path.isfile(full_path) and file.lower().endswith(('.png', '.jpg', '.jpeg', '.bmp')):
                        files.append(full_path)

            if os.path.exists(notes_dir):
                for file in os.listdir(notes_dir):
                    full_path = os.path.join(notes_dir, file)
                    if os.path.isfile(full_path) and file.lower().endswith('.txt'):
                        files.append(full_path)

            if files:
                selected_file = random.choice(files)
                self.open_file(selected_file)

        except Exception as e:
            print(f"Error al abrir archivo automáticamente: {e}")

        self.schedule_auto_open(root)

    def open_file(self, file_path):
        try:
            if file_path.lower().endswith('.txt'):
                if sys.platform == 'win32':
                    os.startfile(file_path)
                else:
                    subprocess.Popen(['xdg-open', file_path])
            else:
                if sys.platform == 'win32':
                    os.startfile(file_path)
                else:
                    opener = 'open' if sys.platform == 'darwin' else 'xdg-open'
                    subprocess.Popen([opener, file_path])

            if self.special_animation_callback:
                self.special_animation_callback()
        except Exception as e:
            print(f"Error al abrir archivo: {e}")

    def toggle_auto_open_pause(self, root):
        self.auto_open_paused = not self.auto_open_paused

        if self.auto_open_timer:
            root.after_cancel(self.auto_open_timer)
            self.auto_open_timer = None

        if not self.auto_open_paused:
            self.schedule_auto_open(root)

        self.save_settings_to_config()

    def find_random_files(self):
        base_path = self.get_base_path()
        txt_files = []
        image_files = []

        notes_dir = os.path.join(base_path, "notas")
        if os.path.exists(notes_dir):
            for file in os.listdir(notes_dir):
                full_path = os.path.join(notes_dir, file)
                if os.path.isfile(full_path) and file.lower().endswith('.txt'):
                    txt_files.append(full_path)

        images_dir = os.path.join(base_path, "imagenes")
        if os.path.exists(images_dir):
            for file in os.listdir(images_dir):
                full_path = os.path.join(images_dir, file)
                if os.path.isfile(full_path) and file.lower().endswith(('.png', '.jpg', '.jpeg', '.bmp')):
                    image_files.append(full_path)

        return txt_files, image_files

    def open_random_file(self):
        txt_files, image_files = self.find_random_files()
        all_files = txt_files + image_files

        if all_files:
            selected_file = random.choice(all_files)
            self.open_file(selected_file)

    def is_auto_open_paused(self):
        return self.auto_open_paused

    def cancel_auto_open_timer(self, root):
        if self.auto_open_timer:
            root.after_cancel(self.auto_open_timer)
            self.auto_open_timer = None