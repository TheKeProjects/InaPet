import os
import json
import time
import base64
import requests
import platform
from tkinter import messagebox as tk_messagebox, Toplevel, Frame, Label, Entry, Text, Scrollbar, Button, filedialog
from PIL import Image


class DiscordIntegration:
    def __init__(self, root, update_manager, skin_manager):
        self.root = root
        self.update_manager = update_manager
        self.skin_manager = skin_manager

        # Multiple webhook URLs for different channels/servers
        self.DISCORD_WEBHOOK_URLS = [
            "https://discord.com/api/webhooks/1422874368043913287/DKyjBl2ibSCZ722PjM9odrN0-Gb75xmOHK7Wo7mQZU3oBqaOAhHJTEnDYjJRuCrSrRMo",
            # Add second webhook URL here if needed
            "https://discord.com/api/webhooks/1422932445652586537/k44TZuPHkZ-QaBUsqAvrQ5q5KUE-x8NGUZ-kDbk37UbjwATf8ikRIRctzBFnKwqPP1Ei"
        ]

        self.attached_sprite_path = None
        self.attached_sprite_data = None

    def show_suggestion_dialog(self):
        dialog = Toplevel(self.root)
        dialog.title("Solicitar Personaje")
        dialog.geometry("550x550")

        # Set the icon to the current skin by converting PNG to ICO
        if hasattr(self.skin_manager, 'current_skin_path') and self.skin_manager.current_skin_path:
            try:
                # Convert current skin PNG to temporary ICO file
                img = Image.open(self.skin_manager.current_skin_path)
                temp_ico_path = os.path.join(os.path.dirname(self.skin_manager.current_skin_path), "temp_dialog_icon.ico")
                img.save(temp_ico_path, format='ICO', sizes=[(32, 32)])
                dialog.iconbitmap(temp_ico_path)
                # Clean up temp file after setting icon
                try:
                    os.remove(temp_ico_path)
                except:
                    pass
            except:
                try:
                    dialog.iconbitmap("inapet.ico")  # Fallback to default icon
                except:
                    pass

        dialog.attributes('-topmost', True)
        dialog.resizable(False, False)

        dialog.transient(self.root)
        dialog.grab_set()

        main_frame = Frame(dialog, padx=20, pady=20)
        main_frame.pack(fill="both", expand=True)

        title_label = Label(main_frame, text="💡 Solicitar Personaje", font=("Arial", 14, "bold"))
        title_label.pack(pady=(0, 15))

        name_frame = Frame(main_frame)
        name_frame.pack(fill="x", pady=(0, 10))

        name_label = Label(name_frame, text="Tu nombre:", font=("Arial", 10, "bold"))
        name_label.pack(anchor="w")

        name_entry = Entry(name_frame, font=("Arial", 10), state="readonly", bg="#f0f0f0")
        name_entry.pack(fill="x", pady=(5, 0))
        name_entry.config(state="normal")
        name_entry.insert(0, platform.node())
        name_entry.config(state="readonly")

        subject_frame = Frame(main_frame)
        subject_frame.pack(fill="x", pady=(0, 10))

        subject_label = Label(subject_frame, text="Asunto:", font=("Arial", 10, "bold"))
        subject_label.pack(anchor="w")

        subject_entry = Entry(subject_frame, font=("Arial", 10))
        subject_entry.pack(fill="x", pady=(5, 0))
        subject_entry.insert(0, "Solicitud de Personaje")
        subject_entry.config(state="readonly", bg="#f0f0f0")

        message_frame = Frame(main_frame)
        message_frame.pack(fill="both", expand=True, pady=(0, 15))

        message_label = Label(message_frame, text="Personaje:", font=("Arial", 10, "bold"))
        message_label.pack(anchor="w")

        message_text = Text(message_frame, height=12, width=50, font=("Arial", 10))
        scrollbar = Scrollbar(message_frame, command=message_text.yview)
        message_text.config(yscrollcommand=scrollbar.set)

        message_text.pack(side="left", fill="both", expand=True)
        scrollbar.pack(side="right", fill="y")

        placeholder_text = "Ingresa tu personaje de Inazuma que quieras ver en InaPet, si puedes, intenta incluir su sprite oficial y usa su nombre europeo y japonés"

        def on_focus_in(event):
            if message_text.get("1.0", "end-1c") == placeholder_text:
                message_text.delete("1.0", "end")
                message_text.config(fg="black")

        def on_focus_out(event):
            if message_text.get("1.0", "end-1c").strip() == "":
                message_text.insert("1.0", placeholder_text)
                message_text.config(fg="gray")

        message_text.insert("1.0", placeholder_text)
        message_text.config(fg="gray")
        message_text.bind("<FocusIn>", on_focus_in)
        message_text.bind("<FocusOut>", on_focus_out)

        attach_frame = Frame(main_frame)
        attach_frame.pack(fill="x", pady=(10, 15))

        def attach_sprite():
            file_path = filedialog.askopenfilename(
                title="Seleccionar Sprite",
                filetypes=[
                    ("Imágenes", "*.png *.jpg *.jpeg *.bmp"),
                    ("Todos los archivos", "*.*")
                ]
            )
            if file_path:
                self.attached_sprite_path = file_path
                file_name = os.path.basename(file_path)
                attach_button.config(text=f"Sprite: {file_name}", bg="#4CAF50", fg="white")

                try:
                    with open(file_path, 'rb') as f:
                        self.attached_sprite_data = base64.b64encode(f.read()).decode('utf-8')
                except Exception as e:
                    print(f"Error al procesar sprite: {e}")
                    self.attached_sprite_data = None

        attach_button = Button(
            attach_frame,
            text="Adjuntar Sprite (Opcional)",
            command=attach_sprite,
            bg="#2196F3",
            fg="white",
            font=("Arial", 9, "bold"),
            width=20
        )
        attach_button.pack(side="left")

        button_frame = Frame(main_frame)
        button_frame.pack(fill="x", pady=(10, 0))

        def send_suggestion():
            user_name = name_entry.get().strip()
            message = message_text.get("1.0", "end-1c").strip()

            if not user_name:
                tk_messagebox.showwarning("Campo vacío", "Por favor, ingresa tu nombre antes de enviar.")
                return

            if message == placeholder_text or not message:
                tk_messagebox.showwarning("Campo vacío", "Por favor, ingresa tu solicitud antes de enviar.")
                return

            success = self.send_discord_suggestion(user_name, message)

            if success:
                tk_messagebox.showinfo("Éxito", "¡Tu solicitud ha sido enviada! Gracias por tu contribución.")
                self.attached_sprite_path = None
                self.attached_sprite_data = None
                attach_button.config(text="Adjuntar Sprite (Opcional)", bg="#2196F3", fg="white")
                dialog.destroy()
            else:
                tk_messagebox.showerror("Error", "No se pudo enviar la solicitud. Por favor, intenta más tarde.")

        def cancel_suggestion():
            self.attached_sprite_path = None
            self.attached_sprite_data = None
            dialog.destroy()

        send_button = Button(button_frame, text="Enviar Solicitud", command=send_suggestion,
                           bg="#4CAF50", fg="white", font=("Arial", 10, "bold"), width=15)
        send_button.pack(side="right", padx=(10, 0))

        cancel_button = Button(button_frame, text="Cancelar", command=cancel_suggestion,
                             bg="#f44336", fg="white", font=("Arial", 10), width=10)
        cancel_button.pack(side="right")

        dialog.update_idletasks()

        # Center window on screen instead of relative to root
        screen_width = dialog.winfo_screenwidth()
        screen_height = dialog.winfo_screenheight()
        x = (screen_width // 2) - (dialog.winfo_width() // 2)
        y = (screen_height // 2) - (dialog.winfo_height() // 2)
        dialog.geometry(f"+{x}+{y}")

        message_text.focus_set()

    def send_discord_suggestion(self, user_name, message):
        """Envía la solicitud a múltiples webhooks de Discord"""
        try:
            embed = {
                "title": "💡 Nueva Solicitud de Personaje",
                "description": (
                    f"`👤 Usuario` \n{user_name}\n"
                    f"`🕒 Fecha` \n{time.strftime('%d-%m-%Y  -  %H:%M:%S', time.localtime())}\n"
                    f"`✏️ Personaje` \n{message[:1024]}\n"
                    f"`🔧 Versión` \nInaPet v{self.update_manager.current_version}\n\n"
                    f"`💡 Sprite`"
                ),
                "color": 5814783,
                "footer": {
                    "text": "Sistema de Sugerencias InaPet"
                }
            }

            files = {}

            if self.attached_sprite_path and os.path.exists(self.attached_sprite_path):
                try:
                    with open(self.attached_sprite_path, 'rb') as f:
                        file_data = f.read()

                    file_name = os.path.basename(self.attached_sprite_path)
                    files['file'] = (file_name, file_data)

                    embed["image"] = {
                        "url": f"attachment://{file_name}"
                    }

                except Exception as e:
                    print(f"Error al procesar sprite: {e}")

            payload = {
                "embeds": [embed],
                "username": "InaPet Sugerencias",
                "avatar_url": "https://i.imgur.com/IhxdyiH.png"
            }

            # Send to all configured webhooks
            successful_sends = 0
            total_webhooks = len(self.DISCORD_WEBHOOK_URLS)

            for i, webhook_url in enumerate(self.DISCORD_WEBHOOK_URLS):
                if not webhook_url or webhook_url.startswith('#'):  # Skip empty or commented URLs
                    continue

                try:
                    if files:
                        # Need to reopen file for each request since requests consumes the data
                        current_files = {}
                        if self.attached_sprite_path and os.path.exists(self.attached_sprite_path):
                            with open(self.attached_sprite_path, 'rb') as f:
                                file_data = f.read()
                            file_name = os.path.basename(self.attached_sprite_path)
                            current_files['file'] = (file_name, file_data)

                        response = requests.post(
                            webhook_url,
                            data={"payload_json": json.dumps(payload)},
                            files=current_files,
                            timeout=10
                        )
                    else:
                        response = requests.post(
                            webhook_url,
                            json=payload,
                            headers={'Content-Type': 'application/json'},
                            timeout=10
                        )

                    if response.status_code in [200, 204]:
                        print(f"✅ Solicitud enviada exitosamente al webhook {i+1}")
                        successful_sends += 1
                    else:
                        print(f"❌ Error en webhook {i+1}: {response.status_code} - {response.text}")

                except Exception as e:
                    print(f"❌ Error enviando a webhook {i+1}: {e}")

            # Return success if at least one webhook received the message
            if successful_sends > 0:
                print(f"🎉 Mensaje enviado exitosamente a {successful_sends}/{total_webhooks} webhooks")
                return True
            else:
                print("❌ No se pudo enviar el mensaje a ningún webhook")
                return False

        except Exception as e:
            print(f"❌ Error general enviando solicitud a Discord: {e}")
            return False