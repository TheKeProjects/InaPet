import json
import os
import sys


class ConfigManager:
    def __init__(self):
        self.CONFIG_FILE = os.path.join(os.path.expanduser('~'), 'Documents', 'InaPet', 'inapet_config.json')
        self.config = self.get_default_config()

    def get_default_config(self):
        return {
            "x": None,
            "y": None,
            "skin_path": None,
            "frozen": False,
            "speed_factor": 1.0,
            "size_factor": 1.0,
            "dx": 1,
            "dy": 1,
            "startup_enabled": False,
            "auto_open_paused": False,
            "music_enabled": False,
            "music_paused": False,
            "music_loop_mode": False,
            "use_custom_playlist": False,
            "custom_playlist": [],
            "music_volume": 0.5,
            "docked_to_taskbar": False,
            "current_song_index": 0,
            "use_japanese_names": False
        }

    def load_config(self):
        try:
            if os.path.exists(self.CONFIG_FILE):
                with open(self.CONFIG_FILE, 'r') as f:
                    saved_config = json.load(f)
                    for key in self.config:
                        if key in saved_config:
                            self.config[key] = saved_config[key]
        except Exception as e:
            print(f"Error cargando configuración: {e}")

    def save_config(self):
        try:
            config_dir = os.path.dirname(self.CONFIG_FILE)
            if not os.path.exists(config_dir):
                os.makedirs(config_dir)

            with open(self.CONFIG_FILE, 'w') as f:
                json.dump(self.config, f, indent=2)
        except Exception as e:
            print(f"Error guardando configuración: {e}")

    def get(self, key, default=None):
        return self.config.get(key, default)

    def set(self, key, value):
        self.config[key] = value

    def update(self, updates):
        self.config.update(updates)