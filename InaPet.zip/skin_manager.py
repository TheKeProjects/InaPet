import os
from PIL import Image, ImageTk


class SkinManager:
    def __init__(self, config_manager, get_base_path_func):
        self.config_manager = config_manager
        self.get_base_path = get_base_path_func
        self.skins_folder = "skins"
        self.skin_categories = {}
        self.folder_logos = {}
        self.current_skin_path = None
        self.use_japanese_names = False
        self.name_mapping = {}

    def load_name_mapping(self):
        nombres_file = os.path.join(self.get_base_path(), "nombres.txt")
        self.name_mapping = {}

        try:
            if os.path.exists(nombres_file):
                with open(nombres_file, 'r', encoding='utf-8') as f:
                    for line in f:
                        line = line.strip()
                        if '=' in line and not line.startswith('#'):
                            occidental, japones = line.split('=', 1)
                            self.name_mapping[occidental.strip()] = japones.strip()
            else:
                with open(nombres_file, 'w', encoding='utf-8') as f:
                    f.write("# Formato: NombreOccidental=NombreJaponés\n")
                    f.write("# También puedes traducir nombres de carpetas\n\n")
                    f.write("# Nombres de personajes\n")
                    f.write("Byron=Hiroto\n")
                    f.write("Axel=Goenji\n")
                    f.write("Mark=Endou\n")
                    f.write("\n# Nombres de carpetas\n")
                    f.write("Inazuma Eleven=イナズマイレブン\n")
                    f.write("Characters=キャラクター\n")
                    f.write("Skins=スキン\n")
        except Exception as e:
            print(f"Error al cargar mapeo de nombres: {e}")

    def get_display_folder_name(self, folder_name):
        if self.use_japanese_names:
            if folder_name in self.name_mapping:
                return self.name_mapping[folder_name]

            words = folder_name.split()
            translated_words = []
            for word in words:
                if word in self.name_mapping:
                    translated_words.append(self.name_mapping[word])
                else:
                    translated_words.append(word)

            return ' '.join(translated_words)
        else:
            return folder_name

    def get_display_name(self, skin_name):
        base_name = os.path.splitext(skin_name)[0]

        if self.use_japanese_names and base_name in self.name_mapping:
            return self.name_mapping[base_name]
        else:
            return base_name

    def toggle_name_mode(self):
        self.use_japanese_names = not self.use_japanese_names
        self.config_manager.set("use_japanese_names", self.use_japanese_names)

    def load_folder_logos(self):
        logos_dir = os.path.join(self.get_base_path(), "logos")
        self.folder_logos = {}

        if not os.path.exists(logos_dir):
            return

        def explore_logos_directory(current_dir):
            try:
                for item in os.listdir(current_dir):
                    item_path = os.path.join(current_dir, item)

                    if os.path.isfile(item_path) and item.lower().endswith(('.png', '.jpg', '.jpeg', '.bmp')):
                        logo_name = os.path.splitext(item)[0]

                        try:
                            logo_img = Image.open(item_path)
                            logo_img.thumbnail((32, 32), Image.LANCZOS)
                            logo_photo = ImageTk.PhotoImage(logo_img)
                            self.folder_logos[logo_name] = logo_photo
                            print(f"Logo cargado: {logo_name} -> {item_path}")
                        except Exception as e:
                            print(f"Error al cargar logo {item_path}: {e}")

                    elif os.path.isdir(item_path):
                        explore_logos_directory(item_path)

            except Exception as e:
                print(f"Error explorando directorio de logos {current_dir}: {e}")

        explore_logos_directory(logos_dir)

    def load_skins(self):
        self.skin_categories = {}
        base_path = self.get_base_path()
        skins_dir = os.path.join(base_path, self.skins_folder)

        self.load_folder_logos()

        if not os.path.exists(skins_dir):
            os.makedirs(skins_dir)
            default_category = "Inazuma Eleven"
            default_dir = os.path.join(skins_dir, default_category)
            os.makedirs(default_dir, exist_ok=True)

            example_img = Image.new('RGBA', (64, 64), (255, 0, 0, 255))
            example_img.save(os.path.join(default_dir, "Byron.jpg"))

        def build_folder_structure(directory, current_path=""):
            structure = {}

            for item in os.listdir(directory):
                item_path = os.path.join(directory, item)

                if os.path.isfile(item_path) and item.lower().endswith(('.png', '.jpg', '.jpeg', '.bmp')):
                    if 'files' not in structure:
                        structure['files'] = []
                    structure['files'].append((item, item_path))

                elif os.path.isdir(item_path):
                    if current_path:
                        new_path = os.path.join(current_path, item)
                    else:
                        new_path = item

                    structure[item] = build_folder_structure(item_path, new_path)

            return structure

        for category in os.listdir(skins_dir):
            category_dir = os.path.join(skins_dir, category)
            if os.path.isdir(category_dir):
                category_structure = build_folder_structure(category_dir, category)

                if category_structure:
                    self.skin_categories[category] = category_structure

        if not self.skin_categories:
            default_category = "Inazuma Eleven"
            default_dir = os.path.join(skins_dir, default_category)
            os.makedirs(default_dir, exist_ok=True)
            default_img = Image.new('RGBA', (64, 64), (0, 255, 0, 255))
            default_path = os.path.join(default_dir, "Byron.jpg")
            default_img.save(default_path)
            self.skin_categories[default_category] = {
                'files': [("Byron.jpg", default_path)]
            }

        self.current_skin_path = self.config_manager.get("skin_path")
        if not self.current_skin_path or not os.path.exists(self.current_skin_path):
            if "Inazuma Eleven" in self.skin_categories:
                byron_skin = None
                def find_byron_skin(structure):
                    nonlocal byron_skin
                    if 'files' in structure:
                        for file_name, file_path in structure['files']:
                            if "Byron.jpg" in file_name:
                                byron_skin = file_path
                                return True
                    for folder_name, substructure in structure.items():
                        if folder_name != 'files':
                            if find_byron_skin(substructure):
                                return True
                    return False

                find_byron_skin(self.skin_categories["Inazuma Eleven"])

                if byron_skin:
                    self.current_skin_path = byron_skin
                else:
                    def get_first_skin(structure):
                        if 'files' in structure and structure['files']:
                            return structure['files'][0][1]
                        for folder_name, substructure in structure.items():
                            if folder_name != 'files':
                                skin = get_first_skin(substructure)
                                if skin:
                                    return skin
                        return None

                    first_skin = get_first_skin(self.skin_categories["Inazuma Eleven"])
                    if first_skin:
                        self.current_skin_path = first_skin
            elif self.skin_categories:
                first_category = list(self.skin_categories.keys())[0]
                def get_first_skin(structure):
                    if 'files' in structure and structure['files']:
                        return structure['files'][0][1]
                    for folder_name, substructure in structure.items():
                        if folder_name != 'files':
                            skin = get_first_skin(substructure)
                            if skin:
                                return skin
                    return None

                first_skin = get_first_skin(self.skin_categories[first_category])
                if first_skin:
                    self.current_skin_path = first_skin
            else:
                default_img = Image.new('RGBA', (64, 64), (0, 255, 0, 255))
                self.current_skin_path = os.path.join(skins_dir, "default_skin.png")
                default_img.save(self.current_skin_path)
                self.skin_categories["Default"] = {
                    'files': [("default_skin.png", self.current_skin_path)]
                }

    def load_settings_from_config(self):
        self.use_japanese_names = self.config_manager.get("use_japanese_names", False)

    def change_skin(self, skin_path):
        self.current_skin_path = skin_path
        self.config_manager.set("skin_path", skin_path)

    def load_pet_image(self, size_factor=1.0):
        BASE_SIZE = 64

        original_image = Image.open(self.current_skin_path).convert("RGBA")
        orig_width, orig_height = original_image.size

        scale = min(BASE_SIZE / orig_width, BASE_SIZE / orig_height)
        new_width = int(orig_width * scale)
        new_height = int(orig_height * scale)

        resized_img = original_image.resize((new_width, new_height), Image.LANCZOS)

        new_image = Image.new("RGBA", (BASE_SIZE, BASE_SIZE), (0, 0, 0, 0))

        x_pos = (BASE_SIZE - new_width) // 2
        y_pos = (BASE_SIZE - new_height) // 2

        new_image.paste(resized_img, (x_pos, y_pos), resized_img)

        final_width = int(BASE_SIZE * size_factor)
        final_height = int(BASE_SIZE * size_factor)

        pet_image = new_image.resize((final_width, final_height), Image.LANCZOS)
        tk_image = ImageTk.PhotoImage(pet_image)

        return pet_image, tk_image