import sys
import os
import threading
import time
import ctypes
import winreg
import pystray
from pystray import MenuItem as item
from PIL import Image


class SystemIntegration:
    def __init__(self, root, config_manager, get_base_path_func, update_docked_position_callback=None):
        self.root = root
        self.config_manager = config_manager
        self.get_base_path = get_base_path_func
        self.update_docked_position_callback = update_docked_position_callback

        self.visible = True
        self.startup_enabled = False
        self.tray_icon = None
        self.tray_thread = None

        self.docked_to_taskbar = False
        self.taskbar_height = 0
        self.taskbar_position = "bottom"
        self.start_button_rect = None
        self.start_button_monitor_thread = None
        self.start_button_monitor_running = False

    def load_settings_from_config(self):
        self.startup_enabled = self.config_manager.get("startup_enabled", False)
        self.docked_to_taskbar = self.config_manager.get("docked_to_taskbar", False)
        self.toggle_startup(self.startup_enabled)

    def save_settings_to_config(self):
        self.config_manager.set("startup_enabled", self.startup_enabled)
        self.config_manager.set("docked_to_taskbar", self.docked_to_taskbar)

    def create_systray_icon(self, current_skin_path=None, skin_categories=None):
        icon_path = os.path.join(self.get_base_path(), "inapet.ico")

        if not os.path.exists(icon_path):
            if current_skin_path and os.path.exists(current_skin_path):
                img = Image.open(current_skin_path)
            elif skin_categories:
                first_category = list(skin_categories.keys())[0]
                first_skin = skin_categories[first_category][0][1]
                img = Image.open(first_skin)
            else:
                img = Image.new('RGBA', (64, 64), (0, 255, 0, 255))

            img = img.resize((64, 64), Image.LANCZOS)
            img.save(icon_path, format='ICO')

        image = Image.open(icon_path)

        menu = (
            item(
                lambda item: "Minimizar" if self.visible else "Mostrar",
                self.toggle_visibility
            ),
            item('Salir', self.quit_app)
        )
        self.tray_icon = pystray.Icon("InaPet", image, "Ina Pet", menu)

        self.tray_thread = threading.Thread(target=self.tray_icon_run, daemon=True)
        self.tray_thread.start()

    def tray_icon_run(self):
        self.tray_icon.run()

    def toggle_visibility(self, icon=None, item=None):
        if self.visible:
            self.minimize_to_tray()
        else:
            self.show_from_tray(icon, item)

    def minimize_to_tray(self):
        self.root.withdraw()
        self.visible = False
        if self.tray_icon:
            self.tray_icon.update_menu()

    def show_from_tray(self, icon, item):
        self.root.deiconify()
        self.root.attributes('-topmost', True)
        self.visible = True
        if self.tray_icon:
            self.tray_icon.update_menu()

    def quit_app(self, icon=None, item=None):
        self.stop_monitoring_start_button()
        if self.tray_icon:
            self.tray_icon.stop()
        self.root.destroy()

    def toggle_startup(self, enabled=None):
        if enabled is None:
            enabled = not self.startup_enabled

        self.startup_enabled = enabled
        app_name = "InaPet"
        app_path = sys.executable if getattr(sys, 'frozen', False) else sys.argv[0]

        try:
            key = winreg.OpenKey(
                winreg.HKEY_CURRENT_USER,
                r"Software\Microsoft\Windows\CurrentVersion\Run",
                0, winreg.KEY_SET_VALUE
            )

            if enabled:
                winreg.SetValueEx(key, app_name, 0, winreg.REG_SZ, f'"{app_path}"')
            else:
                try:
                    winreg.DeleteValue(key, app_name)
                except FileNotFoundError:
                    pass

            winreg.CloseKey(key)
            return True
        except Exception as e:
            print(f"Error configurando inicio automático: {e}")
            return False

    def detect_taskbar_info(self):
        try:
            taskbar_hwnd = ctypes.windll.user32.FindWindowW("Shell_TrayWnd", None)

            rect = ctypes.wintypes.RECT()
            ctypes.windll.user32.GetWindowRect(taskbar_hwnd, ctypes.byref(rect))

            screen_width = self.root.winfo_screenwidth()
            screen_height = self.root.winfo_screenheight()

            if rect.top > 0:
                self.taskbar_position = "bottom"
                self.taskbar_height = rect.bottom - rect.top
            elif rect.left > 0:
                self.taskbar_position = "left"
                self.taskbar_height = rect.right - rect.left
            elif rect.right < screen_width:
                self.taskbar_position = "right"
                self.taskbar_height = rect.right - rect.left
            else:
                self.taskbar_position = "top"
                self.taskbar_height = rect.bottom - rect.top

            def enum_windows_proc(hwnd, lParam):
                class_name = ctypes.create_unicode_buffer(256)
                ctypes.windll.user32.GetClassNameW(hwnd, class_name, 256)

                if "Start" in class_name.value or "Button" in class_name.value:
                    rect = ctypes.wintypes.RECT()
                    ctypes.windll.user32.GetWindowRect(hwnd, ctypes.byref(rect))
                    self.start_button_rect = (rect.left, rect.top, rect.right, rect.bottom)
                    return False
                return True

            enum_proc = ctypes.WINFUNCTYPE(ctypes.wintypes.BOOL, ctypes.wintypes.HWND, ctypes.wintypes.LPARAM)(enum_windows_proc)
            ctypes.windll.user32.EnumChildWindows(taskbar_hwnd, enum_proc, 0)

        except Exception as e:
            print(f"Error al detectar información de la barra de tareas: {e}")
            self.taskbar_height = 48
            self.taskbar_position = "bottom"

    def start_monitoring_start_button(self):
        if self.start_button_monitor_thread is None or not self.start_button_monitor_thread.is_alive():
            self.start_button_monitor_running = True
            self.start_button_monitor_thread = threading.Thread(target=self.monitor_start_button, daemon=True)
            self.start_button_monitor_thread.start()

    def stop_monitoring_start_button(self):
        self.start_button_monitor_running = False

    def monitor_start_button(self):
        last_position = None

        while self.start_button_monitor_running and self.docked_to_taskbar:
            try:
                taskbar_hwnd = ctypes.windll.user32.FindWindowW("Shell_TrayWnd", None)

                def enum_windows_proc(hwnd, lParam):
                    class_name = ctypes.create_unicode_buffer(256)
                    ctypes.windll.user32.GetClassNameW(hwnd, class_name, 256)

                    if "Start" in class_name.value or "Button" in class_name.value:
                        rect = ctypes.wintypes.RECT()
                        ctypes.windll.user32.GetWindowRect(hwnd, ctypes.byref(rect))

                        nonlocal last_position
                        current_position = (rect.left, rect.top, rect.right, rect.bottom)

                        if current_position != last_position:
                            last_position = current_position
                            self.start_button_rect = current_position
                            # Notify main app that start button moved
                            if self.update_docked_position_callback:
                                self.root.after(0, self.update_docked_position_callback)
                            return False
                    return True

                enum_proc = ctypes.WINFUNCTYPE(ctypes.wintypes.BOOL, ctypes.wintypes.HWND, ctypes.wintypes.LPARAM)(enum_windows_proc)
                ctypes.windll.user32.EnumChildWindows(taskbar_hwnd, enum_proc, 0)

            except Exception as e:
                print(f"Error al monitorear botón de inicio: {e}")

            time.sleep(0.5)

    def toggle_dock_to_taskbar(self):
        self.docked_to_taskbar = not self.docked_to_taskbar

        if self.docked_to_taskbar:
            self.detect_taskbar_info()
            self.start_monitoring_start_button()
        else:
            self.stop_monitoring_start_button()

        self.save_settings_to_config()
        return self.docked_to_taskbar

    def get_docked_position(self, pet_image_width, pet_image_height):
        if not self.docked_to_taskbar or not self.start_button_rect:
            return None

        btn_left, btn_top, btn_right, btn_bottom = self.start_button_rect
        btn_width = btn_right - btn_left
        btn_height = btn_bottom - btn_top

        # Position the pet to the left of the start button with some spacing
        spacing = 5

        # Calculate position based on taskbar orientation
        if self.taskbar_position == "bottom" or self.taskbar_position == "top":
            # Horizontal taskbar - place pet to the left of start button
            new_x = btn_left - pet_image_width - spacing
            new_y = btn_top + (btn_height - pet_image_height) // 2
        elif self.taskbar_position == "left":
            # Vertical taskbar on left - place pet above start button
            new_x = btn_left + (btn_width - pet_image_width) // 2
            new_y = btn_top - pet_image_height - spacing
        elif self.taskbar_position == "right":
            # Vertical taskbar on right - place pet above start button
            new_x = btn_left + (btn_width - pet_image_width) // 2
            new_y = btn_top - pet_image_height - spacing
        else:
            # Default to left positioning
            new_x = btn_left - pet_image_width - spacing
            new_y = btn_top + (btn_height - pet_image_height) // 2

        # Ensure the pet stays within screen bounds
        screen_width = self.root.winfo_screenwidth()
        screen_height = self.root.winfo_screenheight()

        new_x = max(0, min(new_x, screen_width - pet_image_width))
        new_y = max(0, min(new_y, screen_height - pet_image_height))

        return new_x, new_y

    def check_visibility(self):
        try:
            self.root.attributes('-topmost', True)

            hwnd = self.root.winfo_id()

            ctypes.windll.user32.BringWindowToTop(hwnd)

            ctypes.windll.user32.SetWindowPos(
                hwnd,
                -1,
                0, 0, 0, 0,
                0x0001 | 0x0002
            )

            if self.docked_to_taskbar and self.start_button_rect:
                start_menu_hwnd = ctypes.windll.user32.FindWindowW("Windows.UI.Core.CoreWindow", "Inicio")
                if start_menu_hwnd:
                    ctypes.windll.user32.SetWindowPos(
                        hwnd,
                        -2,
                        0, 0, 0, 0,
                        0x0001 | 0x0002
                    )

        except Exception as e:
            print(f"Error al verificar visibilidad: {e}")

        self.root.after(100, self.check_visibility)

    def is_docked_to_taskbar(self):
        return self.docked_to_taskbar

    def is_startup_enabled(self):
        return self.startup_enabled

    def toggle_startup_option(self):
        new_state = not self.startup_enabled
        success = self.toggle_startup(new_state)
        if success:
            self.startup_enabled = new_state
            self.save_settings_to_config()
            return True
        return False