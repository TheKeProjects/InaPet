import os
import sys
import threading
import urllib.request
import subprocess
import tempfile
import webbrowser
from tkinter import messagebox as tk_messagebox


class UpdateManager:
    def __init__(self, config_manager, get_base_path_func):
        self.config_manager = config_manager
        self.get_base_path = get_base_path_func

        self.VERSION_FILE = os.path.join(os.path.expanduser('~'), 'Documents', 'InaPet', 'inapet_version.txt')
        self.CHANGELOG_FILE = os.path.join(os.path.expanduser('~'), 'Documents', 'InaPet', 'inapet_changelog.txt')

        self.GITHUB_REPO = "https://raw.githubusercontent.com/TheKeProjects/InaPet/main/version.txt"
        self.GITHUB_CHANGELOG = "https://raw.githubusercontent.com/TheKeProjects/InaPet/main/changelog.txt"
        self.UPDATE_URL = "https://github.com/TheKeProjects/InaPet/releases/latest"
        self.INSTALLER_URL = "https://github.com/TheKeProjects/InaPet/releases/latest/download/InaPet_Update.exe"

        self.current_version = self.get_current_version()
        self.update_available = False

    def get_current_version(self):
        try:
            if os.path.exists(self.VERSION_FILE):
                with open(self.VERSION_FILE, "r") as f:
                    return f.read().strip()
        except:
            pass
        return "1.1.0"

    def save_current_version(self, version):
        try:
            with open(self.VERSION_FILE, "w") as f:
                f.write(version)
        except:
            pass

    def check_for_updates_in_background(self, update_ui_callback=None):
        threading.Thread(target=lambda: self.check_updates(False, update_ui_callback), daemon=True).start()

    def check_updates(self, show_message=False, update_ui_callback=None):
        try:
            current_version = self.get_current_version()
            response = urllib.request.urlopen(self.GITHUB_REPO, timeout=5)
            remote_version = response.read().decode().strip()

            if remote_version != current_version:
                self.update_available = True
                if show_message:
                    self.show_update_prompt(remote_version, current_version)
                if update_ui_callback:
                    update_ui_callback()
            else:
                self.update_available = False
                if show_message:
                    tk_messagebox.showinfo("Actualización", "Ya tienes la última versión.")
                if update_ui_callback:
                    update_ui_callback()
        except Exception as e:
            self.update_available = False
            if show_message:
                tk_messagebox.showerror("Error", f"No se pudo verificar actualizaciones: {str(e)}")
            if update_ui_callback:
                update_ui_callback()

    def download_changelog(self):
        try:
            with urllib.request.urlopen(self.GITHUB_CHANGELOG, timeout=5) as response:
                return response.read().decode('utf-8')
        except Exception as e:
            print(f"Error al descargar changelog: {e}")
            return "No se pudieron obtener las notas de la versión."

    def show_update_prompt(self, remote_version, current_version):
        changelog = self.download_changelog()
        message = f"¡Hay una nueva versión disponible!\n\n" \
                  f"Versión actual: {current_version}\n" \
                  f"Nueva versión: {remote_version}\n\n" \
                  f"Notas de la versión:\n{changelog}\n\n" \
                  "¿Deseas actualizar ahora?"

        if tk_messagebox.askyesno("Actualización disponible", message):
            self.perform_update(remote_version)

    def perform_update(self, remote_version, quit_app_callback=None):
        try:
            changelog = self.download_changelog()
            with open(self.CHANGELOG_FILE, "w", encoding="utf-8") as f:
                f.write(remote_version + "\n\n" + changelog)
        except:
            pass

        if sys.platform == "win32":
            try:
                temp_dir = tempfile.gettempdir()
                installer_path = os.path.join(temp_dir, "InaPet_Updater.exe")

                with urllib.request.urlopen(self.INSTALLER_URL) as response:
                    with open(installer_path, 'wb') as out_file:
                        out_file.write(response.read())

                subprocess.Popen([installer_path, "/SILENT"])
                if quit_app_callback:
                    quit_app_callback()
            except Exception as e:
                tk_messagebox.showerror("Error de actualización",
                                    f"No se pudo descargar el actualizador: {str(e)}\n"
                                    "Por favor, actualiza manualmente desde GitHub.")
                webbrowser.open(self.UPDATE_URL)
        else:
            webbrowser.open(self.UPDATE_URL)
            tk_messagebox.showinfo("Actualización manual", "Por favor, descarga la última versión desde el navegador.")

    def show_update_changes_if_needed(self):
        if os.path.exists(self.CHANGELOG_FILE):
            try:
                with open(self.CHANGELOG_FILE, "r", encoding="utf-8") as f:
                    content = f.read()
                    parts = content.split("\n\n", 1)
                    version = parts[0]
                    changelog = parts[1] if len(parts) > 1 else "No hay notas disponibles."

                tk_messagebox.showinfo(f"Notas de la versión {version}", changelog)
                os.remove(self.CHANGELOG_FILE)
            except Exception as e:
                print(f"Error al mostrar cambios de actualización: {e}")

    def check_updates_ui(self, quit_app_callback=None):
        def check_with_callback():
            self.check_updates(show_message=True)

        threading.Thread(target=check_with_callback, daemon=True).start()

    def is_update_available(self):
        return self.update_available