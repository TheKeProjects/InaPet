from cx_Freeze import setup, Executable

# Opciones de construcción
build_exe_options = {
    "packages": [
        "tkinter",
        "PIL",
        "os",
        "random",
        "subprocess",
        "sys",
        "json",
        "ctypes",
        "threading",
        "pystray",
        "winreg",
        "urllib",
        "tempfile",
        "webbrowser",
        "pygame"
    ],
    "include_files": ["icon.ico", "inapet.ico", ("imagenes/", "imagenes"), ("skins/", "skins"), ("notas/", "notas"), ("musica/", "musica")],
    "excludes": ["tkinter.test", "unittest", "pydoc", "pdb"],
    "include_msvcr": True,
    "silent": True,
}

setup(
    name="InaPet",  # Cambia por el nombre real
    version="1.0.6",
    description="InaPet, tu mascota de escritorio de Inazuma Eleven",
    options={"build_exe": build_exe_options},
    executables=[
        Executable("InaPet.py", base="Win32GUI", icon="icon.ico")  # Cambia por tu nombre de archivo
    ]
)