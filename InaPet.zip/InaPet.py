import tkinter as tk
from PIL import Image, ImageTk, ImageDraw, ImageFont
import os
import random
import subprocess
import time
import sys
import json
import ctypes
import threading
import pystray
from pystray import MenuItem as item
import winreg
import urllib.request
import tempfile
import webbrowser
from tkinter import messagebox as tk_messagebox
import pygame
from tkinter import simpledialog, Listbox, MULTIPLE, END, Scrollbar, Frame, Button, Label, Toplevel, filedialog

class InaPet:
    CONFIG_FILE = os.path.join(os.path.expanduser('~'), 'Documents', 'InaPet', 'inapet_config.json')
    VERSION_FILE = os.path.join(os.path.expanduser('~'), 'Documents', 'InaPet', 'inapet_version.txt')
    CHANGELOG_FILE = os.path.join(os.path.expanduser('~'), 'Documents', 'InaPet', 'inapet_changelog.txt')
    
    # URLs para actualizaciones
    GITHUB_REPO = "https://raw.githubusercontent.com/TheKeProjects/InaPet/main/version.txt"
    GITHUB_CHANGELOG = "https://raw.githubusercontent.com/TheKeProjects/InaPet/main/changelog.txt"
    UPDATE_URL = "https://github.com/TheKeProjects/InaPet/releases/latest"
    INSTALLER_URL = "https://github.com/TheKeProjects/InaPet/releases/latest/download/InaPet_Update.exe"
    
    def __init__(self, root):
        self.root = root
        self.root.overrideredirect(True)
        self.root.attributes('-topmost', True)
        self.root.attributes('-transparentcolor', 'white')
        self.root.protocol("WM_DELETE_WINDOW", self.minimize_to_tray)
        
        # Inicializar variables antes de cargar configuración
        self.dragging = False
        self.drag_data = {"x": 0, "y": 0}
        self.x = 0
        self.y = 0
        self.dx = 0
        self.dy = 0
        self.frozen = False
        self.speed_factor = 1.0
        self.size_factor = 1.0
        self.context_menu = None
        self.visible = True
        self.startup_enabled = False
        self.auto_open_timer = None
        self.update_available = False
        self.current_version = self.get_current_version()
        self.last_menu_x = 0
        self.last_menu_y = 0
        self.auto_open_paused = False
        
        # Nueva variable para el anclaje a la barra de tareas
        self.docked_to_taskbar = False
        self.taskbar_height = 0
        self.taskbar_position = "bottom"  # bottom, top, left, right
        self.start_button_rect = None
        self.start_button_monitor_thread = None
        self.start_button_monitor_running = False
        
        # Inicializar variables de música
        self.music_enabled = False
        self.music_paused = False
        self.music_loop_mode = False  # True: loop misma canción, False: lista secuencial
        self.use_custom_playlist = False  # Indica si se usa la lista personalizada
        self.current_song = None
        self.playlist = []
        self.current_song_index = 0  # Índice para reproducción secuencial
        self.custom_playlist = []  # Lista personalizada de canciones
        self.music_volume = 0.5  # Volumen por defecto (0.0 a 1.0)
        
        # Diccionario para almacenar logos de categorías
        self.category_logos = {}
        
        # Cargar configuraciones
        self.load_config()
        
        # Crear carpetas necesarias
        self.create_required_folders()
        
        # Configuración inicial - cargar skins primero
        self.skins_folder = "skins"
        self.load_skins()
        
        # Cargar imagen de la mascota
        self.load_pet_image()
        self.setup_canvas()
        
        # Detectar información de la barra de tareas
        self.detect_taskbar_info()
        
        # Posición inicial
        self.set_initial_position()
        
        # Aplicar el estado de anclaje después de cargar la configuración
        self.apply_dock_state()
        
        # Verificación periódica de visibilidad
        self.check_visibility()
        
        # Iniciar animación
        self.animate()
        
        # Preparar el ícono para la bandeja del sistema
        self.create_systray_icon()
        
        # Iniciar temporizador para abrir archivos automáticamente
        self.schedule_auto_open()
        
        # Verificar actualizaciones en segundo plano
        self.check_for_updates_in_background()
        
        # Mostrar cambios si es una nueva instalación
        self.show_update_changes_if_needed()
        
        # Inicializar pygame mixer
        pygame.mixer.init()
        pygame.mixer.music.set_volume(self.music_volume)

    def update_ui_for_updates(self):
        """Actualiza la UI para mostrar/ocultar el botón de actualización"""
        # Este método se llama desde el hilo de verificación de actualizaciones
        # para actualizar la interfaz de usuario si hay una actualización disponible
        if self.context_menu:
            self.update_context_menu()
    
    def create_emoji_image(self, emoji_text, size=24):
        """Crea una imagen de emoji usando Segoe UI Emoji - VERSIÓN CORREGIDA"""
        try:
            # Crear una imagen más grande para mejor calidad
            img_size = size + 8  # Agregar padding
            img = Image.new("RGBA", (img_size, img_size), (255, 255, 255, 0))
            draw = ImageDraw.Draw(img)
            
            # Intentar cargar fuentes de emoji
            try:
                # Probar varias fuentes de emoji comunes en Windows
                font_paths = [
                    "C:/Windows/Fonts/seguiemj.ttf",  # Segoe UI Emoji
                    "C:/Windows/Fonts/segoeuiemoji.ttf",  # Segoe UI Emoji alternativa
                    "C:/Windows/Fonts/seguiemj.ttf",  # Segoe UI Emoji
                ]
                
                font = None
                for font_path in font_paths:
                    try:
                        font = ImageFont.truetype(font_path, size)
                        break
                    except:
                        continue
                
                if font is None:
                    # Si no se encuentran fuentes de emoji, usar fuente por defecto
                    font = ImageFont.load_default()
            except:
                font = ImageFont.load_default()
            
            # Calcular posición para centrar el emoji
            bbox = draw.textbbox((0, 0), emoji_text, font=font)
            text_width = bbox[2] - bbox[0]
            text_height = bbox[3] - bbox[1]
            x = (img_size - text_width) // 2
            y = (img_size - text_height) // 2
            
            # Dibujar el emoji centrado
            draw.text((x, y), emoji_text, font=font, fill=(0, 0, 0, 255), embedded_color=True)
            
            # Redimensionar al tamaño final si es necesario
            if img_size != size:
                img = img.resize((size, size), Image.LANCZOS)
            
            return ImageTk.PhotoImage(img)
            
        except Exception as e:
            print(f"Error creando emoji {emoji_text}: {e}")
            # Fallback: crear imagen simple
            img = Image.new("RGBA", (size, size), (255, 255, 255, 0))
            return ImageTk.PhotoImage(img)

    def apply_dock_state(self):
        """Aplica el estado de anclaje según la configuración cargada"""
        if self.docked_to_taskbar:
            # Anclar a la barra de tareas
            self.frozen = True  # Congelar el movimiento aleatorio
            self.detect_taskbar_info()  # Actualizar información de la barra de tareas
            self.start_monitoring_start_button()  # Iniciar monitoreo
            self.update_docked_position()  # Posicionar inicialmente
    
    def detect_taskbar_info(self):
        """Detecta información sobre la barra de tareas de Windows"""
        try:
            # Obtener el handle de la barra de tareas
            taskbar_hwnd = ctypes.windll.user32.FindWindowW("Shell_TrayWnd", None)
            
            # Obtener el rectángulo de la barra de tareas
            rect = ctypes.wintypes.RECT()
            ctypes.windll.user32.GetWindowRect(taskbar_hwnd, ctypes.byref(rect))
            
            # Determinar la posición de la barra de tareas
            screen_width = self.root.winfo_screenwidth()
            screen_height = self.root.winfo_screenheight()
            
            if rect.top > 0:
                self.taskbar_position = "bottom"
                self.taskbar_height = rect.bottom - rect.top
            elif rect.left > 0:
                self.taskbar_position = "left"
                self.taskbar_height = rect.right - rect.left
            elif rect.right < screen_width:
                self.taskbar_position = "right"
                self.taskbar_height = rect.right - rect.left
            else:
                self.taskbar_position = "top"
                self.taskbar_height = rect.bottom - rect.top
                
            # Buscar el botón de inicio (Windows 11)
            def enum_windows_proc(hwnd, lParam):
                class_name = ctypes.create_unicode_buffer(256)
                ctypes.windll.user32.GetClassNameW(hwnd, class_name, 256)
                
                if "Start" in class_name.value or "Button" in class_name.value:
                    rect = ctypes.wintypes.RECT()
                    ctypes.windll.user32.GetWindowRect(hwnd, ctypes.byref(rect))
                    self.start_button_rect = (rect.left, rect.top, rect.right, rect.bottom)
                    return False  # Detener la enumeración
                return True  # Continuar enumeración
            
            # Enumerar ventanas hijas de la barra de tareas
            enum_proc = ctypes.WINFUNCTYPE(ctypes.wintypes.BOOL, ctypes.wintypes.HWND, ctypes.wintypes.LPARAM)(enum_windows_proc)
            ctypes.windll.user32.EnumChildWindows(taskbar_hwnd, enum_proc, 0)
            
        except Exception as e:
            print(f"Error al detectar información de la barra de tareas: {e}")
            # Valores por defecto si no se puede detectar
            self.taskbar_height = 48  # Altura típica de la barra de tareas de Windows 11
            self.taskbar_position = "bottom"
    
    def start_monitoring_start_button(self):
        """Inicia el monitoreo de la posición del botón de inicio"""
        if self.start_button_monitor_thread is None or not self.start_button_monitor_thread.is_alive():
            self.start_button_monitor_running = True
            self.start_button_monitor_thread = threading.Thread(target=self.monitor_start_button, daemon=True)
            self.start_button_monitor_thread.start()
    
    def stop_monitoring_start_button(self):
        """Detiene el monitoreo de la posición del botón de inicio"""
        self.start_button_monitor_running = False
    
    def monitor_start_button(self):
        """Monitorea la posición del botón de inicio y ajusta la posición de la mascota"""
        last_position = None
        
        while self.start_button_monitor_running and self.docked_to_taskbar:
            try:
                # Obtener el handle de la barra de tareas
                taskbar_hwnd = ctypes.windll.user32.FindWindowW("Shell_TrayWnd", None)
                
                # Buscar el botón de inicio
                def enum_windows_proc(hwnd, lParam):
                    class_name = ctypes.create_unicode_buffer(256)
                    ctypes.windll.user32.GetClassNameW(hwnd, class_name, 256)
                    
                    if "Start" in class_name.value or "Button" in class_name.value:
                        rect = ctypes.wintypes.RECT()
                        ctypes.windll.user32.GetWindowRect(hwnd, ctypes.byref(rect))
                        
                        nonlocal last_position
                        current_position = (rect.left, rect.top, rect.right, rect.bottom)
                        
                        # Si la posición cambió, actualizar la mascota
                        if current_position != last_position:
                            last_position = current_position
                            self.start_button_rect = current_position
                            self.update_docked_position()
                        return False  # Detener la enumeración
                    return True  # Continuar enumeración
                
                # Enumerar ventanas hijas de la barra de tareas
                enum_proc = ctypes.WINFUNCTYPE(ctypes.wintypes.BOOL, ctypes.wintypes.HWND, ctypes.wintypes.LPARAM)(enum_windows_proc)
                ctypes.windll.user32.EnumChildWindows(taskbar_hwnd, enum_proc, 0)
                
            except Exception as e:
                print(f"Error al monitorear botón de inicio: {e}")
            
            # Esperar un poco antes de verificar nuevamente
            time.sleep(0.5)
    
    def update_docked_position(self):
        """Actualiza la posición de la mascota cuando está anclada a la barra de tareas"""
        if not self.docked_to_taskbar or not self.start_button_rect:
            return
        
        # Calcular la nueva posición basada en el botón de inicio
        btn_left, btn_top, btn_right, btn_bottom = self.start_button_rect
        btn_width = btn_right - btn_left
        btn_height = btn_bottom - btn_top
        
        # Posicionar la mascota a la izquierda del botón de inicio
        new_x = btn_left - self.pet_image.width - 5  # 5px de separación
        new_y = btn_top - (self.pet_image.height - btn_height) // 2
        
        # Asegurarse de que esté dentro de los límites de la pantalla
        screen_width = self.root.winfo_screenwidth()
        screen_height = self.root.winfo_screenheight()
        
        if new_x < 0:
            new_x = 0
        if new_y < 0:
            new_y = 0
        if new_x + self.pet_image.width > screen_width:
            new_x = screen_width - self.pet_image.width
        if new_y + self.pet_image.height > screen_height:
            new_y = screen_height - self.pet_image.height
        
        # Suavizar el movimiento con una animación
        self.animate_to_position(new_x, new_y)
    
    def animate_to_position(self, target_x, target_y):
        """Anima el movimiento de la mascota a una nueva posición"""
        steps = 10
        current_x = self.x
        current_y = self.y
        
        for i in range(1, steps + 1):
            if not self.docked_to_taskbar:  # Detener si se cancela el anclaje
                break
                
            new_x = current_x + (target_x - current_x) * i / steps
            new_y = current_y + (target_y - current_y) * i / steps
            
            self.x = new_x
            self.y = new_y
            self.root.geometry(f"+{int(new_x)}+{int(new_y)}")
            
            time.sleep(0.02)  # Pequeña pausa para la animación
            self.root.update()
    
    def toggle_dock_to_taskbar(self):
        """Alterna el anclaje a la barra de tareas"""
        self.docked_to_taskbar = not self.docked_to_taskbar
        
        if self.docked_to_taskbar:
            # Anclar a la barra de tareas
            self.frozen = True  # Congelar el movimiento aleatorio
            self.detect_taskbar_info()  # Actualizar información de la barra de tareas
            self.start_monitoring_start_button()  # Iniciar monitoreo
            self.update_docked_position()  # Posicionar inicialmente
        else:
            # Desanclar de la barra de tareas
            self.frozen = False
            self.stop_monitoring_start_button()  # Detener monitoreo
        
        self.update_context_menu()
        self.save_config()

    def adjust_size(self, delta):
        """Ajusta el tamaño de la mascota"""
        self.size_factor += delta
        self.size_factor = max(0.5, min(self.size_factor, 2.0))
        
        # Guardar centro actual
        old_center_x = self.x + self.pet_image.width // 2
        old_center_y = self.y + self.pet_image.height // 2
        
        # Recargar imagen con nuevo tamaño
        self.load_pet_image()
        
        # Actualizar canvas
        self.canvas.itemconfig(self.pet, image=self.tk_image)
        self.canvas.config(width=self.pet_image.width, height=self.pet_image.height)
        
        # Calcular nueva posición para mantener el centro
        new_width = self.pet_image.width
        new_height = self.pet_image.height
        self.x = old_center_x - new_width // 2
        self.y = old_center_y - new_height // 2
        
        # Ajustar a los bordes de la pantalla
        screen_width = self.root.winfo_screenwidth()
        screen_height = self.root.winfo_screenheight()
        self.x = max(0, min(self.x, screen_width - new_width))
        self.y = max(0, min(self.y, screen_height - new_height))
        
        # Actualizar geometría
        self.root.geometry(f"{new_width}x{new_height}+{int(self.x)}+{int(self.y)}")
        
        # Si está anclado, actualizar posición
        if self.docked_to_taskbar:
            self.update_docked_position()
        
        # Guardar configuración
        self.save_config()
        
        # Actualizar menú
        self.update_context_menu()
    
    def reset_size(self):
        """Restablece el tamaño predeterminado"""
        self.size_factor = 1.0
        self.adjust_size(0)
    
    def get_current_version(self):
        """Obtiene la versión actual de la aplicación"""
        try:
            if os.path.exists(self.VERSION_FILE):
                with open(self.VERSION_FILE, "r") as f:
                    return f.read().strip()
        except:
            pass
        return "1.0.7"
    
    def save_current_version(self, version):
        """Guarda la versión actual en un archivo"""
        try:
            with open(self.VERSION_FILE, "w") as f:
                f.write(version)
        except:
            pass
    
    def check_for_updates_in_background(self):
        """Verifica actualizaciones en segundo plano"""
        threading.Thread(target=self.check_updates, daemon=True).start()
    
    def check_updates(self, show_message=False):
        """Verifica si hay actualizaciones disponibles en GitHub"""
        try:
            current_version = self.get_current_version()
            response = urllib.request.urlopen(self.GITHUB_REPO, timeout=5)
            remote_version = response.read().decode().strip()
            
            if remote_version != current_version:
                self.update_available = True
                if show_message:
                    self.show_update_prompt(remote_version, current_version)
                self.root.after(0, self.update_ui_for_updates)
            else:
                self.update_available = False
                if show_message:
                    tk_messagebox.showinfo("Actualización", "Ya tienes la última versión.")
                self.root.after(0, self.update_ui_for_updates)
        except Exception as e:
            self.update_available = False
            if show_message:
                tk_messagebox.showerror("Error", f"No se pudo verificar actualizaciones: {str(e)}")
            self.root.after(0, self.update_ui_for_updates)
    
    def download_changelog(self):
        """Descarga el changelog desde GitHub"""
        try:
            with urllib.request.urlopen(self.GITHUB_CHANGELOG, timeout=5) as response:
                return response.read().decode('utf-8')
        except Exception as e:
            print(f"Error al descargar changelog: {e}")
            return "No se pudieron obtener las notas de la versión."
    
    def show_update_prompt(self, remote_version, current_version):
        """Muestra un diálogo informando sobre la nueva versión"""
        changelog = self.download_changelog()
        message = f"¡Hay una nueva versión disponible!\n\n" \
                  f"Versión actual: {current_version}\n" \
                  f"Nueva versión: {remote_version}\n\n" \
                  f"Notas de la versión:\n{changelog}\n\n" \
                  "¿Deseas actualizar ahora?"
        
        if tk_messagebox.askyesno("Actualización disponible", message):
            self.perform_update(remote_version)
    
    def perform_update(self, remote_version):
        """Realiza el proceso de actualización"""
        try:
            changelog = self.download_changelog()
            with open(self.CHANGELOG_FILE, "w", encoding="utf-8") as f:
                f.write(remote_version + "\n\n" + changelog)
        except:
            pass
        
        if sys.platform == "win32":
            try:
                temp_dir = tempfile.gettempdir()
                installer_path = os.path.join(temp_dir, "InaPet_Updater.exe")
                
                with urllib.request.urlopen(self.INSTALLER_URL) as response:
                    with open(installer_path, 'wb') as out_file:
                        out_file.write(response.read())
                
                subprocess.Popen([installer_path, "/SILENT"])
                self.quit_app()
            except Exception as e:
                tk_messagebox.showerror("Error de actualización", 
                                    f"No se pudo descargar el actualizador: {str(e)}\n"
                                    "Por favor, actualiza manualmente desde GitHub.")
                webbrowser.open(self.UPDATE_URL)
        else:
            webbrowser.open(self.UPDATE_URL)
            tk_messagebox.showinfo("Actualización manual", "Por favor, descarga la última versión desde el navegador.")
    
    def show_update_changes_if_needed(self):
        """Muestra los cambios si se acaba de actualizar"""
        if os.path.exists(self.CHANGELOG_FILE):
            try:
                with open(self.CHANGELOG_FILE, "r", encoding="utf-8") as f:
                    content = f.read()
                    parts = content.split("\n\n", 1)
                    version = parts[0]
                    changelog = parts[1] if len(parts) > 1 else "No hay notas disponibles."
                
                tk_messagebox.showinfo(f"Notas de la versión {version}", changelog)
                os.remove(self.CHANGELOG_FILE)
            except Exception as e:
                print(f"Error al mostrar cambios de actualización: {e}")
    
    def create_required_folders(self):
        """Crear carpetas necesarias si no existen"""
        base_path = self.get_base_path()
        folders = ["imagenes", "notas", "musica", "logos"]
        
        for folder in folders:
            folder_path = os.path.join(base_path, folder)
            if not os.path.exists(folder_path):
                os.makedirs(folder_path)
                if folder == "notas":
                    with open(os.path.join(folder_path, "ejemplo.txt"), "w") as f:
                        f.write("¡Esta es una nota de ejemplo!\nGuarda aquí tus notas importantes.")
                elif folder == "imagenes":
                    img = Image.new('RGB', (100, 100), color=(73, 109, 137))
                    img.save(os.path.join(folder_path, "ejemplo.png"))
    
    def schedule_auto_open(self):
        """Programar la apertura automática de archivos"""
        if self.auto_open_timer:
            self.root.after_cancel(self.auto_open_timer)
            self.auto_open_timer = None
        
        if not self.auto_open_paused:
            interval = random.randint(30000, 300000)
            self.auto_open_timer = self.root.after(interval, self.auto_open_file)
    
    def auto_open_file(self):
        """Abrir un archivo aleatorio automáticamente"""
        if self.auto_open_paused:
            self.schedule_auto_open()
            return
            
        try:
            files_dir = os.path.join(self.get_base_path(), "imagenes")
            notes_dir = os.path.join(self.get_base_path(), "notas")
            files = []
            
            if os.path.exists(files_dir):
                for file in os.listdir(files_dir):
                    full_path = os.path.join(files_dir, file)
                    if os.path.isfile(full_path) and file.lower().endswith(('.png', '.jpg', '.jpeg', '.bmp')):
                        files.append(full_path)
            
            if os.path.exists(notes_dir):
                for file in os.listdir(notes_dir):
                    full_path = os.path.join(notes_dir, file)
                    if os.path.isfile(full_path) and file.lower().endswith('.txt'):
                        files.append(full_path)
            
            if files:
                selected_file = random.choice(files)
                self.open_file(selected_file)
        
        except Exception as e:
            print(f"Error al abrir archivo automáticamente: {e}")
        
        self.schedule_auto_open()
    
    def open_file(self, file_path):
        """Abre un archivo (imagen o nota)"""
        try:
            if file_path.lower().endswith('.txt'):
                if sys.platform == 'win32':
                    os.startfile(file_path)
                else:
                    subprocess.Popen(['xdg-open', file_path])
            else:
                if sys.platform == 'win32':
                    os.startfile(file_path)
                else:
                    opener = 'open' if sys.platform == 'darwin' else 'xdg-open'
                    subprocess.Popen([opener, file_path])
            
            self.special_animation()
        except Exception as e:
            print(f"Error al abrir archivo: {e}")
    
    def toggle_auto_open_pause(self):
        """Alterna el estado de pausa para los popups automáticos"""
        self.auto_open_paused = not self.auto_open_paused
        
        if self.auto_open_timer:
            self.root.after_cancel(self.auto_open_timer)
            self.auto_open_timer = None
        
        if not self.auto_open_paused:
            self.schedule_auto_open()
        
        self.update_context_menu()
        self.save_config()
    
    def create_systray_icon(self):
        """Crear ícono en el área de notificaciones"""
        icon_path = os.path.join(self.get_base_path(), "inapet.ico")
        
        if not os.path.exists(icon_path):
            if hasattr(self, 'current_skin_path') and self.current_skin_path:
                img = Image.open(self.current_skin_path)
            elif self.skin_categories:
                first_category = list(self.skin_categories.keys())[0]
                first_skin = self.skin_categories[first_category][0][1]
                img = Image.open(first_skin)
            else:
                img = Image.new('RGBA', (64, 64), (0, 255, 0, 255))
                
            img = img.resize((64, 64), Image.LANCZOS)
            img.save(icon_path, format='ICO')
        
        image = Image.open(icon_path)
        
        menu = (
            item(
                lambda item: "Minimizar" if self.visible else "Mostrar",
                self.toggle_visibility
            ),
            item('Salir', self.quit_app)
        )
        self.tray_icon = pystray.Icon("InaPet", image, "Ina Pet", menu)
        
        self.tray_thread = threading.Thread(target=self.tray_icon_run, daemon=True)
        self.tray_thread.start()
    
    def toggle_visibility(self, icon, item):
        if self.visible:
            self.minimize_to_tray()
        else:
            self.show_from_tray(icon, item)
    
    def tray_icon_run(self):
        self.tray_icon.run()
    
    def minimize_to_tray(self):
        self.root.withdraw()
        self.visible = False
        self.tray_icon.update_menu()
    
    def show_from_tray(self, icon, item):
        self.root.deiconify()
        self.root.attributes('-topmost', True)
        self.visible = True
        self.tray_icon.update_menu()
    
    def quit_app(self, icon=None, item=None):
        self.save_config()
        self.stop_monitoring_start_button()
        self.tray_icon.stop()
        pygame.mixer.quit()
        self.root.destroy()
    
    def load_config(self):
        self.config = {
            "x": None,
            "y": None,
            "skin_path": None,
            "frozen": False,
            "speed_factor": 1.0,
            "size_factor": 1.0,
            "dx": random.choice([-2, -1, 1, 2]),
            "dy": random.choice([-2, -1, 1, 2]),
            "startup_enabled": False,
            "auto_open_paused": False,
            "music_enabled": False,
            "music_paused": False,
            "music_loop_mode": False,
            "use_custom_playlist": False,
            "custom_playlist": [],
            "music_volume": 0.5,
            "docked_to_taskbar": False,
            "current_song_index": 0  # Nueva configuración para guardar el índice de la canción actual
        }
        
        try:
            if os.path.exists(self.CONFIG_FILE):
                with open(self.CONFIG_FILE, 'r') as f:
                    saved_config = json.load(f)
                    for key in self.config:
                        if key in saved_config:
                            self.config[key] = saved_config[key]
            
            self.startup_enabled = self.config["startup_enabled"]
            self.auto_open_paused = self.config["auto_open_paused"]
            self.size_factor = self.config["size_factor"]
            self.music_enabled = self.config["music_enabled"]
            self.music_paused = self.config["music_paused"]
            self.music_loop_mode = self.config["music_loop_mode"]
            self.use_custom_playlist = self.config["use_custom_playlist"]
            self.custom_playlist = self.config["custom_playlist"]
            self.music_volume = self.config["music_volume"]
            self.docked_to_taskbar = self.config["docked_to_taskbar"]
            self.current_song_index = self.config.get("current_song_index", 0)  # Cargar índice de canción
            
            self.toggle_startup(self.startup_enabled)
            
        except Exception as e:
            print(f"Error cargando configuración: {e}")
    
    def save_config(self):
        try:
            config_dir = os.path.dirname(self.CONFIG_FILE)
            if not os.path.exists(config_dir):
                os.makedirs(config_dir)
                
            self.config.update({
                "x": self.x,
                "y": self.y,
                "skin_path": self.current_skin_path,
                "frozen": self.frozen,
                "speed_factor": self.speed_factor,
                "size_factor": self.size_factor,
                "dx": self.dx,
                "dy": self.dy,
                "startup_enabled": self.startup_enabled,
                "auto_open_paused": self.auto_open_paused,
                "music_enabled": self.music_enabled,
                "music_paused": self.music_paused,
                "music_loop_mode": self.music_loop_mode,
                "use_custom_playlist": self.use_custom_playlist,
                "custom_playlist": self.custom_playlist,
                "music_volume": self.music_volume,
                "docked_to_taskbar": self.docked_to_taskbar,
                "current_song_index": self.current_song_index  # Guardar índice de canción
            })
            
            with open(self.CONFIG_FILE, 'w') as f:
                json.dump(self.config, f, indent=2)
        except Exception as e:
            print(f"Error guardando configuración: {e}")
    
    def toggle_startup(self, enabled=None):
        """Activar/desactivar inicio automático con Windows"""
        if enabled is None:
            enabled = not self.startup_enabled
            
        self.startup_enabled = enabled
        app_name = "InaPet"
        app_path = sys.executable if getattr(sys, 'frozen', False) else sys.argv[0]
        
        try:
            key = winreg.OpenKey(
                winreg.HKEY_CURRENT_USER,
                r"Software\Microsoft\Windows\CurrentVersion\Run",
                0, winreg.KEY_SET_VALUE
            )
            
            if enabled:
                winreg.SetValueEx(key, app_name, 0, winreg.REG_SZ, f'"{app_path}"')
            else:
                try:
                    winreg.DeleteValue(key, app_name)
                except FileNotFoundError:
                    pass
            
            winreg.CloseKey(key)
            return True
        except Exception as e:
            print(f"Error configurando inicio automático: {e}")
            return False
    
    def load_category_logos(self):
        """Carga los logos para cada categoría desde la carpeta logos"""
        logos_dir = os.path.join(self.get_base_path(), "logos")
        self.category_logos = {}
        
        if os.path.exists(logos_dir):
            for logo_file in os.listdir(logos_dir):
                if logo_file.lower().endswith(('.png', '.jpg', '.jpeg', '.bmp')):
                    # El nombre del archivo sin extensión debería coincidir con el nombre de la categoría
                    category_name = os.path.splitext(logo_file)[0]
                    logo_path = os.path.join(logos_dir, logo_file)
                    
                    try:
                        # Cargar y redimensionar el logo
                        logo_img = Image.open(logo_path)
                        logo_img.thumbnail((32, 32), Image.LANCZOS)
                        logo_photo = ImageTk.PhotoImage(logo_img)
                        self.category_logos[category_name] = logo_photo
                    except Exception as e:
                        print(f"Error al cargar logo para categoría {category_name}: {e}")
    
    def load_skins(self):
        """Carga las skins organizadas por carpetas y subcarpetas"""
        self.skin_categories = {}
        base_path = self.get_base_path()
        skins_dir = os.path.join(base_path, self.skins_folder)
        
        # Cargar logos de categorías
        self.load_category_logos()
        
        if not os.path.exists(skins_dir):
            os.makedirs(skins_dir)
            default_category = "Inazuma Eleven"
            default_dir = os.path.join(skins_dir, default_category)
            os.makedirs(default_dir, exist_ok=True)
            
            # Crear una imagen de ejemplo para Byron
            example_img = Image.new('RGBA', (64, 64), (255, 0, 0, 255))
            example_img.save(os.path.join(default_dir, "Byron.jpg"))
            
        # Función recursiva para explorar subcarpetas
        def find_skins(directory):
            skin_list = []
            for entry in os.listdir(directory):
                full_path = os.path.join(directory, entry)
                if os.path.isfile(full_path) and entry.lower().endswith(('.png', '.jpg', '.jpeg', '.bmp')):
                    skin_list.append(full_path)
                elif os.path.isdir(full_path):
                    skin_list.extend(find_skins(full_path))
            return skin_list

        # Recorrer carpetas de categorías principales
        for category in os.listdir(skins_dir):
            category_dir = os.path.join(skins_dir, category)
            if os.path.isdir(category_dir):
                category_skins = find_skins(category_dir)
                
                if category_skins:
                    # Usar ruta relativa para mostrar estructura de carpetas
                    relative_skins = []
                    for skin_path in category_skins:
                        rel_path = os.path.relpath(skin_path, category_dir)
                        relative_skins.append((rel_path, skin_path))
                    
                    self.skin_categories[category] = relative_skins

        # Si no hay categorías, crear una por defecto
        if not self.skin_categories:
            default_category = "Inazuma Eleven"
            default_dir = os.path.join(skins_dir, default_category)
            os.makedirs(default_dir, exist_ok=True)
            default_img = Image.new('RGBA', (64, 64), (0, 255, 0, 255))
            default_path = os.path.join(default_dir, "Byron.jpg")
            default_img.save(default_path)
            self.skin_categories[default_category] = [("Byron.jpg", default_path)]
        
        # Cargar skin actual
        self.current_skin_path = self.config.get("skin_path")
        if not self.current_skin_path or not os.path.exists(self.current_skin_path):
            # Buscar específicamente la skin Byron.jpg en Inazuma Eleven
            if "Inazuma Eleven" in self.skin_categories:
                byron_skin = None
                for skin_name, skin_path in self.skin_categories["Inazuma Eleven"]:
                    if "Byron.jpg" in skin_name:
                        byron_skin = skin_path
                        break
                
                if byron_skin:
                    self.current_skin_path = byron_skin
                elif self.skin_categories["Inazuma Eleven"]:
                    self.current_skin_path = self.skin_categories["Inazuma Eleven"][0][1]
            elif self.skin_categories:
                first_category = list(self.skin_categories.keys())[0]
                self.current_skin_path = self.skin_categories[first_category][0][1]
            else:
                # Último recurso: crear una skin por defecto
                default_img = Image.new('RGBA', (64, 64), (0, 255, 0, 255))
                self.current_skin_path = os.path.join(skins_dir, "default_skin.png")
                default_img.save(self.current_skin_path)
                self.skin_categories["Default"] = [("default_skin.png", self.current_skin_path)]

    def setup_canvas(self):
        self.canvas = tk.Canvas(self.root, width=self.pet_image.width, 
                               height=self.pet_image.height, 
                               highlightthickness=0, bg='white')
        self.canvas.pack()
        self.pet = self.canvas.create_image(0, 0, image=self.tk_image, anchor='nw')
        
        self.canvas.tag_bind(self.pet, '<ButtonPress-1>', self.on_press)
        self.canvas.tag_bind(self.pet, '<B1-Motion>', self.on_drag)
        self.canvas.tag_bind(self.pet, '<ButtonRelease-1>', self.on_release)
        self.canvas.tag_bind(self.pet, '<Double-Button-1>', self.open_random_file)
        self.canvas.tag_bind(self.pet, '<Button-3>', self.show_context_menu)
    
    def load_pet_image(self):
        """Carga la imagen de la mascota forzando el tamaño a 64x64 con fondo transparente"""
        # Tamaño base forzado a 64x64
        BASE_SIZE = 64
        
        # Cargar imagen original
        original_image = Image.open(self.current_skin_path).convert("RGBA")
        orig_width, orig_height = original_image.size
        
        # Calcular nueva escala manteniendo relación de aspecto
        scale = min(BASE_SIZE / orig_width, BASE_SIZE / orig_height)
        new_width = int(orig_width * scale)
        new_height = int(orig_height * scale)
        
        # Redimensionar manteniendo calidad
        resized_img = original_image.resize((new_width, new_height), Image.LANCZOS)
        
        # Crear una nueva imagen 64x64 transparente
        new_image = Image.new("RGBA", (BASE_SIZE, BASE_SIZE), (0, 0, 0, 0))
        
        # Calcular posición para centrar la imagen
        x_pos = (BASE_SIZE - new_width) // 2
        y_pos = (BASE_SIZE - new_height) // 2
        
        # Pegar la imagen redimensionada en el centro
        new_image.paste(resized_img, (x_pos, y_pos), resized_img)
        
        # Aplicar factor de tamaño
        final_width = int(BASE_SIZE * self.size_factor)
        final_height = int(BASE_SIZE * self.size_factor)
        
        # Redimensionar a tamaño final
        self.pet_image = new_image.resize((final_width, final_height), Image.LANCZOS)
        self.tk_image = ImageTk.PhotoImage(self.pet_image)
    
    def get_base_path(self):
        if getattr(sys, 'frozen', False):
            return os.path.dirname(sys.executable)
        return os.path.dirname(os.path.abspath(__file__))
    
    def set_initial_position(self):
        screen_width = self.root.winfo_screenwidth()
        screen_height = self.root.winfo_screenheight()
        
        if self.config["x"] is not None and self.config["y"] is not None:
            self.x = self.config["x"]
            self.y = self.config["y"]
        else:
            self.x = random.randint(0, screen_width - self.pet_image.width)
            self.y = random.randint(0, screen_height - self.pet_image.height)
        
        self.root.geometry(f"{self.pet_image.width}x{self.pet_image.height}+{int(self.x)}+{int(self.y)}")
        
        self.dx = self.config["dx"]
        self.dy = self.config["dy"]
        self.frozen = self.config["frozen"]
        self.speed_factor = self.config["speed_factor"]
    
    def check_visibility(self):
        # Mantener la ventana siempre visible y en primer plano
        try:
            # Forzar que la ventana esté siempre en primer plano
            self.root.attributes('-topmost', True)
            
            # Usar Windows API para asegurar que la ventana esté siempre visible
            hwnd = self.root.winfo_id()
            
            # Traer la ventana al frente
            ctypes.windll.user32.BringWindowToTop(hwnd)
            
            # Forzar que la ventana se mantenga en primer plano
            ctypes.windll.user32.SetWindowPos(
                hwnd, 
                -1,  # HWND_TOPMOST: coloca la ventana por encima de todas las no topmost
                0, 0, 0, 0,
                0x0001 | 0x0002  # SWP_NOSIZE | SWP_NOMOVE: mantiene tamaño y posición actual
            )
            
            # Asegurar que la ventana esté visible incluso cuando se abre el menú de inicio
            if self.docked_to_taskbar and self.start_button_rect:
                # Si está anclado a la barra de tareas, verificar si el menú de inicio está abierto
                start_menu_hwnd = ctypes.windll.user32.FindWindowW("Windows.UI.Core.CoreWindow", "Inicio")
                if start_menu_hwnd:
                    # Si el menú de inicio está abierto, asegurar que nuestra ventana esté por encima
                    ctypes.windll.user32.SetWindowPos(
                        hwnd,
                        -2,  # HWND_TOPMOST: coloca la ventana por encima de todas las no topmost
                        0, 0, 0, 0,
                        0x0001 | 0x0002  # SWP_NOSIZE | SWP_NOMOVE
                    )
            
        except Exception as e:
            print(f"Error al verificar visibilidad: {e}")
        
        # Continuar verificando periódicamente
        self.root.after(100, self.check_visibility)
    
    def on_press(self, event):
        self.dragging = True
        self.drag_data["x"] = event.x_root
        self.drag_data["y"] = event.y_root
        self.root.attributes('-topmost', True)
        
        # Si está anclado, desanclar al comenzar a arrastrar
        if self.docked_to_taskbar:
            self.toggle_dock_to_taskbar()
    
    def on_drag(self, event):
        if self.dragging:
            screen_width = self.root.winfo_screenwidth()
            screen_height = self.root.winfo_screenheight()
            pet_width = self.pet_image.width
            pet_height = self.pet_image.height
            
            dx = event.x_root - self.drag_data["x"]
            dy = event.y_root - self.drag_data["y"]
            
            self.x += dx
            self.y += dy
            
            # Mantener dentro de los límites de la pantalla
            self.x = max(0, min(self.x, screen_width - pet_width))
            self.y = max(0, min(self.y, screen_height - pet_height))
            
            self.root.geometry(f"+{int(self.x)}+{int(self.y)}")
            self.drag_data["x"] = event.x_root
            self.drag_data["y"] = event.y_root
    
    def on_release(self, event):
        self.dragging = False
        if not self.frozen:
            self.dx = random.choice([-2, -1, 1, 2])
            self.dy = random.choice([-2, -1, 1, 2])
        self.save_config()
    
    def show_context_menu(self, event):
        self.last_menu_x = event.x_root
        self.last_menu_y = event.y_root
        self.show_context_menu_at_position(event.x_root, event.y_root)
    
    def show_context_menu_at_position(self, x, y):
        if self.context_menu:
            self.context_menu.destroy()
            
        self.context_menu = tk.Menu(self.root, tearoff=0)
        
        # Crear imágenes de emoji para el menú - TAMAÑO AUMENTADO
        pause_emoji = self.create_emoji_image("⏸️", 20)
        play_emoji = self.create_emoji_image("▶️", 20)
        minimize_emoji = self.create_emoji_image("📱", 20)
        dock_emoji = self.create_emoji_image("📌", 20)
        undock_emoji = self.create_emoji_image("🔓", 20)
        
        # Opción Fijar/Desfijar
        if not self.frozen:
            self.context_menu.add_command(label="Pausar", image=pause_emoji, compound=tk.LEFT, command=self.toggle_freeze)
        else:
            self.context_menu.add_command(label="Reanudar", image=play_emoji, compound=tk.LEFT, command=self.toggle_freeze)
        
        # Opción Minimizar
        self.context_menu.add_command(label="Minimizar", image=minimize_emoji, compound=tk.LEFT, command=self.minimize_to_tray)
        
        # Botón para pausar/reanudar popups automáticos
        if not self.auto_open_paused:
            self.context_menu.add_command(label="Pausar popups", image=pause_emoji, compound=tk.LEFT, command=self.toggle_auto_open_pause)
        else:
            self.context_menu.add_command(label="Reanudar popups", image=play_emoji, compound=tk.LEFT, command=self.toggle_auto_open_pause)
        
        # Nueva opción para anclar/desanclar de la barra de tareas
        if not self.docked_to_taskbar:
            self.context_menu.add_command(label="Anclar a barra de tareas", image=dock_emoji, compound=tk.LEFT, command=self.toggle_dock_to_taskbar)
        else:
            self.context_menu.add_command(label="Desanclar de barra de tareas", image=undock_emoji, compound=tk.LEFT, command=self.toggle_dock_to_taskbar)
        
        # Menú de skins organizado por categorías y subcarpetas
        if self.skin_categories:
            skin_menu = tk.Menu(self.context_menu, tearoff=0)
            skin_emoji = self.create_emoji_image("🎭", 20)
            
            for category, skins in self.skin_categories.items():
                category_menu = tk.Menu(skin_menu, tearoff=0)
                
                # Agregar logo de la categoría si existe
                category_logo = None
                if category in self.category_logos:
                    category_logo = self.category_logos[category]
                
                # Agrupar por estructura de carpetas
                folder_structure = {}
                for rel_path, abs_path in skins:
                    folders = os.path.dirname(rel_path).split(os.sep)
                    file_name = os.path.basename(rel_path)
                    
                    current_level = folder_structure
                    for folder in folders:
                        if folder:  # Ignorar carpetas vacías
                            if folder not in current_level:
                                current_level[folder] = {}
                            current_level = current_level[folder]
                    
                    # Agregar archivo al nivel actual
                    if 'files' not in current_level:
                        current_level['files'] = []
                    current_level['files'].append((file_name, abs_path))
                
                # Función recursiva para crear menús
                def add_menu_items(menu, structure, level=0):
                    # Agregar archivos primero
                    if 'files' in structure:
                        for file_name, abs_path in structure['files']:
                            skin_name = os.path.splitext(file_name)[0]
                            
                            # Crear una miniatura de la skin
                            try:
                                thumb_img = Image.open(abs_path)
                                thumb_img.thumbnail((32, 32), Image.LANCZOS)
                                thumb_photo = ImageTk.PhotoImage(thumb_img)
                                
                                # Añadir al menú con imagen
                                menu.add_command(
                                    label=skin_name,
                                    image=thumb_photo,
                                    compound=tk.LEFT,
                                    command=lambda p=abs_path: self.change_skin(p)
                                )
                                
                                # Guardar referencia para evitar garbage collection
                                if not hasattr(menu, 'thumbnails'):
                                    menu.thumbnails = []
                                menu.thumbnails.append(thumb_photo)
                            except Exception as e:
                                print(f"Error al cargar miniatura: {e}")
                                menu.add_command(
                                    label=skin_name,
                                    command=lambda p=abs_path: self.change_skin(p)
                                )
                    
                    # Luego agregar subcarpetas
                    for folder, substructure in structure.items():
                        if folder != 'files':  # 'files' es clave especial para archivos
                            submenu = tk.Menu(menu, tearoff=0)
                            add_menu_items(submenu, substructure, level + 1)
                            
                            # Buscar logo para la subcarpeta
                            subfolder_logo = None
                            subfolder_logo_path = os.path.join(self.get_base_path(), "logos", f"{folder}.png")
                            if os.path.exists(subfolder_logo_path):
                                try:
                                    logo_img = Image.open(subfolder_logo_path)
                                    logo_img.thumbnail((32, 32), Image.LANCZOS)
                                    subfolder_logo = ImageTk.PhotoImage(logo_img)
                                except Exception as e:
                                    print(f"Error al cargar logo para subcarpeta {folder}: {e}")
                            
                            # Agregar submenú con logo si está disponible
                            if subfolder_logo:
                                menu.add_cascade(label=folder, menu=submenu, image=subfolder_logo, compound=tk.LEFT)
                                # Guardar referencia de la imagen
                                if not hasattr(menu, 'subfolder_logos'):
                                    menu.subfolder_logos = []
                                menu.subfolder_logos.append(subfolder_logo)
                            else:
                                menu.add_cascade(label=folder, menu=submenu)
                
                add_menu_items(category_menu, folder_structure)
                
                # Agregar categoría al menú principal con logo si está disponible
                if category_logo:
                    skin_menu.add_cascade(label=category, menu=category_menu, image=category_logo, compound=tk.LEFT)
                else:
                    skin_menu.add_cascade(label=category, menu=category_menu)
            
            self.context_menu.add_cascade(label="Skins", menu=skin_menu, image=skin_emoji, compound=tk.LEFT)
        else:
            no_skin_emoji = self.create_emoji_image("❌", 20)
            self.context_menu.add_command(label="No hay skins disponibles", image=no_skin_emoji, compound=tk.LEFT, state=tk.DISABLED)
        
        self.context_menu.add_separator()
        
        # Crear emojis para menús de velocidad y tamaño - TAMAÑO AUMENTADO
        speed_emoji = self.create_emoji_image("⚡", 20)
        size_emoji = self.create_emoji_image("📏", 20)
        slower_emoji = self.create_emoji_image("➖", 20)
        faster_emoji = self.create_emoji_image("➕", 20)
        reset_emoji = self.create_emoji_image("♻️", 20)
        
        # Menú de velocidad
        speed_menu = tk.Menu(self.context_menu, tearoff=0)
        speed_menu.add_command(label="Más lento", image=slower_emoji, compound=tk.LEFT, command=lambda: self.adjust_speed(-0.2))
        speed_menu.add_command(label="Normal", image=reset_emoji, compound=tk.LEFT, command=self.reset_speed)
        speed_menu.add_command(label="Más rápido", image=faster_emoji, compound=tk.LEFT, command=lambda: self.adjust_speed(0.2))
        self.context_menu.add_cascade(label=f"Velocidad: {self.speed_factor:.1f}x", menu=speed_menu, image=speed_emoji, compound=tk.LEFT)
        
        # Menú de tamaño
        size_menu = tk.Menu(self.context_menu, tearoff=0)
        size_menu.add_command(label="Más pequeño", image=slower_emoji, compound=tk.LEFT, command=lambda: self.adjust_size(-0.1))
        size_menu.add_command(label="Tamaño normal", image=reset_emoji, compound=tk.LEFT, command=self.reset_size)
        size_menu.add_command(label="Más grande", image=faster_emoji, compound=tk.LEFT, command=lambda: self.adjust_size(0.1))
        self.context_menu.add_cascade(label=f"Tamaño: {self.size_factor:.1f}x", menu=size_menu, image=size_emoji, compound=tk.LEFT)
        
        # Opción de inicio automático
        startup_emoji = self.create_emoji_image("⏰", 20)
        check_emoji = self.create_emoji_image("✅", 20)
        if self.startup_enabled:
            self.context_menu.add_command(label="Abrir al inicio", image=check_emoji, compound=tk.LEFT, command=self.toggle_startup_option)
        else:
            self.context_menu.add_command(label="Abrir al inicio", image=startup_emoji, compound=tk.LEFT, command=self.toggle_startup_option)
        
        # Opción de actualización
        update_emoji = self.create_emoji_image("🔄", 20)
        search_emoji = self.create_emoji_image("🔍", 20)
        if self.update_available:
            self.context_menu.add_command(label="Actualización disponible!", image=update_emoji, compound=tk.LEFT, command=self.check_updates_ui)
        else:
            self.context_menu.add_command(label="Buscar actualizaciones", image=search_emoji, compound=tk.LEFT, command=self.check_updates_ui)
        
        # ===== Menú de música =====
        music_menu = tk.Menu(self.context_menu, tearoff=0)
        music_emoji = self.create_emoji_image("🎵", 20)
        
        # Estado de la música
        if self.music_enabled:
            music_state_emoji = self.create_emoji_image("✅", 20)
            music_menu.add_command(
                label=f"Música: Activada", 
                image=music_state_emoji, 
                compound=tk.LEFT,
                command=self.toggle_music
            )
        else:
            music_state_emoji = self.create_emoji_image("❌", 20)
            music_menu.add_command(
                label=f"Música: Desactivada", 
                image=music_state_emoji, 
                compound=tk.LEFT,
                command=self.toggle_music
            )
        
        # Controles de reproducción (solo si la música está activada)
        if self.music_enabled:
            if not self.music_paused:
                pause_music_emoji = self.create_emoji_image("⏸️", 20)
                music_menu.add_command(label="Pausar", image=pause_music_emoji, compound=tk.LEFT, command=self.toggle_music_pause)
            else:
                play_music_emoji = self.create_emoji_image("▶️", 20)
                music_menu.add_command(label="Reanudar", image=play_music_emoji, compound=tk.LEFT, command=self.toggle_music_pause)
            
            if self.music_loop_mode:
                loop_emoji = self.create_emoji_image("🔂", 20)
                music_menu.add_command(label="Loop: Misma canción", image=loop_emoji, compound=tk.LEFT, command=self.change_loop_mode)
            else:
                playlist_emoji = self.create_emoji_image("📋", 20)
                music_menu.add_command(label="Loop: Lista secuencial", image=playlist_emoji, compound=tk.LEFT, command=self.change_loop_mode)
            
            # Volumen
            vol_menu = tk.Menu(music_menu, tearoff=0)
            vol_up_emoji = self.create_emoji_image("➕", 20)
            vol_down_emoji = self.create_emoji_image("➖", 20)
            mute_emoji = self.create_emoji_image("🔇", 20)
            vol_menu.add_command(label="Subir volumen", image=vol_up_emoji, compound=tk.LEFT, command=lambda: self.adjust_volume(0.1))
            vol_menu.add_command(label="Bajar volumen", image=vol_down_emoji, compound=tk.LEFT, command=lambda: self.adjust_volume(-0.1))
            vol_menu.add_command(label="Silenciar", image=mute_emoji, compound=tk.LEFT, command=lambda: self.adjust_volume(-self.music_volume))
            volume_emoji = self.create_emoji_image("🔊", 20)
            music_menu.add_cascade(label=f"Volumen: {int(self.music_volume * 100)}%", menu=vol_menu, image=volume_emoji, compound=tk.LEFT)
            
            # Opción de lista personalizada
            music_menu.add_separator()
            if self.use_custom_playlist:
                custom_playlist_emoji = self.create_emoji_image("✅", 20)
                music_menu.add_command(label="Lista personal", image=custom_playlist_emoji, compound=tk.LEFT, command=self.toggle_custom_playlist)
            else:
                custom_playlist_emoji = self.create_emoji_image("📝", 20)
                music_menu.add_command(label="Lista personal", image=custom_playlist_emoji, compound=tk.LEFT, command=self.toggle_custom_playlist)
            
            edit_emoji = self.create_emoji_image("✏️", 20)
            music_menu.add_command(label="Editar lista personal", image=edit_emoji, compound=tk.LEFT, command=self.open_custom_playlist_editor)
            
            # Botones de navegación de canciones
            music_menu.add_separator()
            prev_emoji = self.create_emoji_image("⏮", 20)
            next_emoji = self.create_emoji_image("⏭", 20)
            music_menu.add_command(label="Canción anterior", image=prev_emoji, compound=tk.LEFT, command=self.prev_song)
            music_menu.add_command(label="Canción siguiente", image=next_emoji, compound=tk.LEFT, command=self.play_next_song)
            
            # Mostrar canción actual
            if self.current_song:
                music_menu.add_separator()
                current_song_emoji = self.create_emoji_image("🎶", 20)
                song_name = os.path.basename(self.current_song)
                music_menu.add_command(label=f"Reproduciendo: {song_name}", image=current_song_emoji, compound=tk.LEFT, state=tk.DISABLED)
        
        self.context_menu.add_cascade(label="Música", menu=music_menu, image=music_emoji, compound=tk.LEFT)
        # ===== Fin de menú de música =====
        
        self.context_menu.add_separator()
        
        # Botón salir
        exit_emoji = self.create_emoji_image("❌", 20)
        self.context_menu.add_command(label="Salir", image=exit_emoji, compound=tk.LEFT, command=self.quit_app)
        
        self.context_menu.post(x, y)
    
    def update_context_menu(self):
        if self.context_menu:
            self.context_menu.destroy()
            self.context_menu = None
            self.show_context_menu_at_position(self.last_menu_x, self.last_menu_y)
    
    def toggle_startup_option(self):
        new_state = not self.startup_enabled
        success = self.toggle_startup(new_state)
        if success:
            self.startup_enabled = new_state
            self.save_config()
            self.update_context_menu()
    
    def check_updates_ui(self):
        self.check_updates(show_message=True)
    
    def toggle_freeze(self):
        self.frozen = not self.frozen
        if not self.frozen:
            self.dx = random.choice([-2, -1, 1, 2])
            self.dy = random.choice([-2, -1, 1, 2])
        self.save_config()
        self.update_context_menu()
    
    def change_skin(self, skin_path):
        self.current_skin_path = skin_path
        self.load_pet_image()
        self.canvas.itemconfig(self.pet, image=self.tk_image)
        self.canvas.config(width=self.pet_image.width, height=self.pet_image.height)
        
        screen_width = self.root.winfo_screenwidth()
        screen_height = self.root.winfo_screenheight()
        new_width = self.pet_image.width
        new_height = self.pet_image.height
        
        if self.x > screen_width - new_width:
            self.x = screen_width - new_width
        
        if self.y > screen_height - new_height:
            self.y = screen_height - new_height
        
        self.root.geometry(f"{new_width}x{new_height}+{int(self.x)}+{int(self.y)}")
        
        # Si está anclado, actualizar posición
        if self.docked_to_taskbar:
            self.update_docked_position()
            
        self.save_config()
    
    def adjust_speed(self, delta):
        self.speed_factor += delta
        self.speed_factor = max(0.2, min(self.speed_factor, 3.0))
        self.save_config()
        self.update_context_menu()
    
    def reset_speed(self):
        self.speed_factor = 1.0
        self.save_config()
        self.update_context_menu()
    
    def find_random_files(self):
        base_path = self.get_base_path()
        txt_files = []
        image_files = []
        
        notes_dir = os.path.join(base_path, "notas")
        if os.path.exists(notes_dir):
            for file in os.listdir(notes_dir):
                full_path = os.path.join(notes_dir, file)
                if os.path.isfile(full_path) and file.lower().endswith('.txt'):
                    txt_files.append(full_path)
        
        images_dir = os.path.join(base_path, "imagenes")
        if os.path.exists(images_dir):
            for file in os.listdir(images_dir):
                full_path = os.path.join(images_dir, file)
                if os.path.isfile(full_path) and file.lower().endswith(('.png', '.jpg', '.jpeg', '.bmp')):
                    image_files.append(full_path)
        
        return txt_files, image_files
    
    def open_random_file(self, event):
        txt_files, image_files = self.find_random_files()
        all_files = txt_files + image_files
        
        if all_files:
            selected_file = random.choice(all_files)
            self.open_file(selected_file)
    
    def special_animation(self):
        original_x = self.x
        
        for i in range(10):
            if i % 2 == 0:
                self.root.geometry(f"+{int(self.x + 5)}+{int(self.y)}")
            else:
                self.root.geometry(f"+{int(self.x - 5)}+{int(self.y)}")
            
            self.root.update()
            time.sleep(0.03)
        
        self.root.geometry(f"+{int(original_x)}+{int(self.y)}")
        self.x = original_x
    
    def animate(self):
        if not self.dragging and not self.frozen and not self.docked_to_taskbar:
            self.x += self.dx * self.speed_factor
            self.y += self.dy * self.speed_factor
            
            screen_width = self.root.winfo_screenwidth()
            screen_height = self.root.winfo_screenheight()
            pet_width = self.pet_image.width
            pet_height = self.pet_image.height
            
            if self.x <= 0:
                self.x = 0
                self.dx = abs(self.dx)
            elif self.x >= screen_width - pet_width:
                self.x = screen_width - pet_width
                self.dx = -abs(self.dx)
            
            if self.y <= 0:
                self.y = 0
                self.dy = abs(self.dy)
            elif self.y >= screen_height - pet_height:
                self.y = screen_height - pet_height
                self.dy = -abs(self.dy)
            
            self.root.geometry(f"+{int(self.x)}+{int(self.y)}")
        
        self.root.after(30, self.animate)
    
    # ===== Funciones de música actualizadas =====
    def setup_music(self):
        """Cargar lista de canciones disponibles"""
        music_dir = os.path.join(self.get_base_path(), "musica")
        self.playlist = []
        
        if os.path.exists(music_dir):
            for root, _, files in os.walk(music_dir):
                for file in files:
                    full_path = os.path.join(root, file)
                    if os.path.isfile(full_path) and file.lower().endswith(('.mp3', '.wav', '.ogg')):
                        self.playlist.append(full_path)
    
    def toggle_music(self):
        """Activar/desactivar música"""
        self.music_enabled = not self.music_enabled
        
        if self.music_enabled:
            if not self.playlist and not self.custom_playlist:
                self.setup_music()
                
            if self.playlist or self.custom_playlist:
                # Reiniciar el índice cuando se activa la música
                self.current_song_index = 0
                self.play_next_song()
            else:
                self.music_enabled = False
                tk_messagebox.showinfo("Música", "No hay canciones en la carpeta 'musica'")
        else:
            pygame.mixer.music.stop()
        
        self.update_context_menu()
        self.save_config()
    
    def toggle_music_pause(self):
        """Pausar/reanudar música"""
        if not self.music_enabled:
            return
            
        self.music_paused = not self.music_paused
        
        if self.music_paused:
            pygame.mixer.music.pause()
        else:
            pygame.mixer.music.unpause()
        
        self.update_context_menu()
        self.save_config()
    
    def change_loop_mode(self):
        """Cambiar modo de reproducción"""
        self.music_loop_mode = not self.music_loop_mode
        self.update_context_menu()
        self.save_config()
    
    def toggle_custom_playlist(self):
        """Activar/desactivar lista personalizada"""
        self.use_custom_playlist = not self.use_custom_playlist
        # Reiniciar el índice cuando se cambia de lista
        self.current_song_index = 0
        self.update_context_menu()
        self.save_config()
        
        # Si la música está activada y cambiamos la lista, pasamos a la siguiente canción
        if self.music_enabled and not self.music_paused:
            pygame.mixer.music.stop()
            self.play_next_song()
    
    def adjust_volume(self, delta):
        """Ajustar volumen"""
        self.music_volume = max(0.0, min(1.0, self.music_volume + delta))
        pygame.mixer.music.set_volume(self.music_volume)
        self.update_context_menu()
        self.save_config()
    
    def prev_song(self):
        """Reproducir canción anterior"""
        if not self.music_enabled or not (self.playlist or self.custom_playlist):
            return
            
        # Determinar qué lista usar
        playlist = self.custom_playlist if self.use_custom_playlist and self.custom_playlist else self.playlist
        
        if not playlist:
            return
            
        # Decrementar índice y asegurarse de que esté dentro de los límites
        self.current_song_index = (self.current_song_index - 1) % len(playlist)
        song_path = playlist[self.current_song_index]
        
        try:
            pygame.mixer.music.load(song_path)
            pygame.mixer.music.play()
            pygame.mixer.music.set_volume(self.music_volume)
            self.current_song = song_path
        except Exception as e:
            print(f"Error al reproducir canción: {e}")
    
    def play_next_song(self):
        """Reproducir siguiente canción en orden"""
        # Si la música está desactivada o pausada, no hacer nada
        if not self.music_enabled or self.music_paused:
            return
            
        # Determinar qué lista usar
        if self.use_custom_playlist and self.custom_playlist:
            playlist = self.custom_playlist
        else:
            playlist = self.playlist
            
        if not playlist:
            self.music_enabled = False
            self.update_context_menu()
            return
            
        # Si está en modo loop, reproducir la misma canción
        if self.music_loop_mode and self.current_song:
            song_path = self.current_song
        else:
            # Reproducir en orden secuencial
            song_path = playlist[self.current_song_index]
            self.current_song_index = (self.current_song_index + 1) % len(playlist)
        
        try:
            pygame.mixer.music.load(song_path)
            pygame.mixer.music.play()
            pygame.mixer.music.set_volume(self.music_volume)
            self.current_song = song_path
            
            # Verificar cuando termine la canción para pasar a la siguiente
            if not self.music_loop_mode:
                threading.Thread(target=self.wait_for_song_end, daemon=True).start()
        except Exception as e:
            print(f"Error al reproducir canción: {e}")
            # Intentar con la siguiente canción
            self.current_song_index = (self.current_song_index + 1) % len(playlist)
            self.play_next_song()
    
    def wait_for_song_end(self):
        """Esperar a que termine la canción actual"""
        while pygame.mixer.music.get_busy():
            time.sleep(0.5)
        
        if self.music_enabled and not self.music_paused:
            self.play_next_song()
    
    def open_custom_playlist_editor(self):
        """Abre el editor de lista personalizada"""
        editor = Toplevel(self.root)
        editor.title("Editor de Lista Personal")
        editor.geometry("600x400")
        editor.attributes('-topmost', True)
        
        # Marco principal
        main_frame = Frame(editor)
        main_frame.pack(fill="both", expand=True, padx=10, pady=10)
        
        # Etiqueta
        Label(main_frame, text="Selecciona canciones para tu lista personal:").pack(pady=5)
        
        # Lista de todas las canciones disponibles
        all_songs = []
        music_dir = os.path.join(self.get_base_path(), "musica")
        if os.path.exists(music_dir):
            for root, _, files in os.walk(music_dir):
                for file in files:
                    full_path = os.path.join(root, file)
                    if os.path.isfile(full_path) and file.lower().endswith(('.mp3', '.wav', '.ogg')):
                        all_songs.append(full_path)
        
        # Listbox con scroll
        frame = Frame(main_frame)
        frame.pack(fill="both", expand=True)
        
        scrollbar = Scrollbar(frame)
        scrollbar.pack(side="right", fill="y")
        
        song_list = Listbox(frame, selectmode=MULTIPLE, yscrollcommand=scrollbar.set, width=80)
        song_list.pack(side="left", fill="both", expand=True)
        scrollbar.config(command=song_list.yview)
        
        # Insertar canciones
        for song in all_songs:
            # Mostrar nombre de archivo y ruta
            rel_path = os.path.relpath(song, music_dir)
            song_list.insert(END, rel_path)
            # Guardar la ruta completa como dato extra
            song_list.itemconfig(END, {'bg': 'light yellow' if song in self.custom_playlist else 'white'})
        
        # Preseleccionar las canciones que ya están en la lista personal
        for i, song in enumerate(all_songs):
            if song in self.custom_playlist:
                song_list.selection_set(i)
        
        # Botones
        button_frame = Frame(main_frame)
        button_frame.pack(pady=10)
        
        def save_playlist():
            selected_indices = song_list.curselection()
            new_playlist = [all_songs[i] for i in selected_indices]
            self.custom_playlist = new_playlist
            # Reiniciar el índice cuando se cambia la lista
            self.current_song_index = 0
            self.save_config()
            editor.destroy()
            self.update_context_menu()
            
            # Si se usa la lista personal y la música está activada, reiniciar reproducción
            if self.music_enabled and self.use_custom_playlist:
                pygame.mixer.music.stop()
                self.play_next_song()
        
        Button(button_frame, text="Guardar", command=save_playlist).pack(side="left", padx=5)
        Button(button_frame, text="Cancelar", command=editor.destroy).pack(side="left", padx=5)
    
    # ===== Fin de funciones de música actualizadas =====

if __name__ == "__main__":
    root = tk.Tk()
    root.config(bg='white')
    pet = InaPet(root)
    root.mainloop()