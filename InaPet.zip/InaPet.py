import tkinter as tk
from PIL import ImageTk
import os
import sys
import random
from tkinter import Listbox, MULTIPLE, END, Scrollbar, Frame, Button, Label, Toplevel

from config_manager import ConfigManager
from music_manager import MusicManager
from ui_manager import UIManager
from skin_manager import SkinManager
from animation_manager import AnimationManager
from system_integration import SystemIntegration
from update_manager import UpdateManager
from file_manager import FileManager
from discord_integration import DiscordIntegration


class InaPet:
    def __init__(self, root):
        self.root = root
        self.root.overrideredirect(True)
        self.root.attributes('-topmost', True)
        self.root.attributes('-transparentcolor', 'white')
        self.root.protocol("WM_DELETE_WINDOW", self.minimize_to_tray)

        self.pet_image = None
        self.tk_image = None
        self.canvas = None
        self.pet = None
        self.size_factor = 1.0

        self._initialize_managers()
        self._load_configurations()
        self._setup_ui()
        self._setup_callbacks()

    def _initialize_managers(self):
        self.config_manager = ConfigManager()

        self.music_manager = MusicManager(
            self.config_manager,
            self.get_base_path,
            self.update_context_menu
        )

        self.skin_manager = SkinManager(
            self.config_manager,
            self.get_base_path
        )

        self.animation_manager = AnimationManager(
            self.root,
            self.config_manager
        )

        self.system_integration = SystemIntegration(
            self.root,
            self.config_manager,
            self.get_base_path,
            self.update_docked_position
        )

        self.update_manager = UpdateManager(
            self.config_manager,
            self.get_base_path
        )

        self.file_manager = FileManager(
            self.config_manager,
            self.get_base_path,
            self.animation_manager.special_animation
        )

        self.discord_integration = DiscordIntegration(
            self.root,
            self.update_manager,
            self.skin_manager
        )

        self.ui_manager = UIManager(
            self.root,
            self.skin_manager,
            self.music_manager,
            self.config_manager
        )

    def _load_configurations(self):
        self.config_manager.load_config()
        self.size_factor = self.config_manager.get("size_factor", 1.0)

        self.music_manager.load_settings_from_config()
        self.skin_manager.load_settings_from_config()
        self.animation_manager.load_settings_from_config()
        self.system_integration.load_settings_from_config()
        self.file_manager.load_settings_from_config()

    def _setup_ui(self):
        self.file_manager.create_required_folders()
        self.skin_manager.load_name_mapping()
        self.skin_manager.load_skins()
        self.load_pet_image()
        self.setup_canvas()

        self.system_integration.detect_taskbar_info()
        self.animation_manager.set_pet_image(self.pet_image)
        self.animation_manager.set_initial_position()

        self.apply_dock_state()
        self.system_integration.check_visibility()
        self.animation_manager.animate()

        self.system_integration.create_systray_icon(
            self.skin_manager.current_skin_path,
            self.skin_manager.skin_categories
        )

        self.file_manager.schedule_auto_open(self.root)
        self.update_manager.check_for_updates_in_background(self.update_ui_for_updates)
        self.update_manager.show_update_changes_if_needed()

    def _setup_callbacks(self):
        self.callbacks = {
            'is_frozen': lambda: self.animation_manager.is_frozen(),
            'is_auto_open_paused': lambda: self.file_manager.is_auto_open_paused(),
            'is_docked_to_taskbar': lambda: self.animation_manager.is_docked_to_taskbar(),
            'is_using_japanese_names': lambda: self.skin_manager.use_japanese_names,
            'is_startup_enabled': lambda: self.system_integration.is_startup_enabled(),
            'is_update_available': lambda: self.update_manager.is_update_available(),
            'get_speed_factor': lambda: self.animation_manager.get_speed_factor(),
            'get_size_factor': lambda: self.size_factor,

            'toggle_freeze': self.toggle_freeze,
            'toggle_auto_open_pause': self.toggle_auto_open_pause,
            'toggle_dock_to_taskbar': self.toggle_dock_to_taskbar,
            'toggle_name_mode': self.toggle_name_mode,
            'toggle_startup_option': self.toggle_startup_option,
            'change_skin': self.change_skin,
            'adjust_speed': self.adjust_speed,
            'reset_speed': self.reset_speed,
            'adjust_size': self.adjust_size,
            'reset_size': self.reset_size,
            'check_updates_ui': self.check_updates_ui,
            'show_suggestion_dialog': self.show_suggestion_dialog,
            'minimize_to_tray': self.minimize_to_tray,
            'quit_app': self.quit_app,

            'toggle_music': self.toggle_music,
            'toggle_music_pause': self.toggle_music_pause,
            'change_loop_mode': self.change_loop_mode,
            'toggle_custom_playlist': self.toggle_custom_playlist,
            'adjust_volume': self.adjust_volume,
            'prev_song': self.prev_song,
            'play_next_song': self.play_next_song,
            'open_custom_playlist_editor': self.open_custom_playlist_editor,
        }

    def get_base_path(self):
        if getattr(sys, 'frozen', False):
            return os.path.dirname(sys.executable)
        return os.path.dirname(os.path.abspath(__file__))

    def load_pet_image(self):
        self.pet_image, self.tk_image = self.skin_manager.load_pet_image(self.size_factor)

    def setup_canvas(self):
        self.canvas = tk.Canvas(self.root, width=self.pet_image.width,
                               height=self.pet_image.height,
                               highlightthickness=0, bg='white')
        self.canvas.pack()
        self.pet = self.canvas.create_image(0, 0, image=self.tk_image, anchor='nw')

        self.canvas.tag_bind(self.pet, '<ButtonPress-1>', self.on_press)
        self.canvas.tag_bind(self.pet, '<B1-Motion>', self.on_drag)
        self.canvas.tag_bind(self.pet, '<ButtonRelease-1>', self.on_release)
        self.canvas.tag_bind(self.pet, '<Double-Button-1>', self.open_random_file)
        self.canvas.tag_bind(self.pet, '<Button-3>', self.show_context_menu)

    def apply_dock_state(self):
        if self.animation_manager.is_docked_to_taskbar():
            self.animation_manager.set_docked_state(True)
            self.system_integration.start_monitoring_start_button()
            self.update_docked_position()

    def update_docked_position(self):
        if not self.animation_manager.is_docked_to_taskbar():
            return

        position = self.system_integration.get_docked_position(
            self.pet_image.width,
            self.pet_image.height
        )

        if position:
            new_x, new_y = position
            self.animation_manager.animate_to_position(new_x, new_y)

    def on_press(self, event):
        self.animation_manager.on_press(event, self.toggle_dock_to_taskbar)

    def on_drag(self, event):
        self.animation_manager.on_drag(event)

    def on_release(self, event):
        self.animation_manager.on_release(event)
        self.save_config()

    def show_context_menu(self, event):
        self.ui_manager.create_context_menu(event.x_root, event.y_root, self.callbacks)

    def update_context_menu(self):
        self.ui_manager.update_context_menu(self.callbacks)

    def update_ui_for_updates(self):
        if hasattr(self, 'ui_manager') and self.ui_manager.context_menu:
            self.update_context_menu()

    def toggle_freeze(self):
        self.animation_manager.toggle_freeze()
        self.save_config()
        self.update_context_menu()

    def toggle_auto_open_pause(self):
        self.file_manager.toggle_auto_open_pause(self.root)
        self.update_context_menu()

    def toggle_dock_to_taskbar(self):
        docked = self.system_integration.toggle_dock_to_taskbar()

        if docked:
            self.animation_manager.set_docked_state(True)
            self.system_integration.start_monitoring_start_button()
            self.update_docked_position()
        else:
            self.animation_manager.set_docked_state(False)
            self.system_integration.stop_monitoring_start_button()

        self.update_context_menu()
        self.save_config()

    def toggle_name_mode(self):
        self.skin_manager.toggle_name_mode()
        self.update_context_menu()
        self.save_config()

    def toggle_startup_option(self):
        success = self.system_integration.toggle_startup_option()
        if success:
            self.save_config()
            self.update_context_menu()

    def change_skin(self, skin_path):
        old_width = self.pet_image.width
        old_height = self.pet_image.height

        self.skin_manager.change_skin(skin_path)
        self.load_pet_image()
        self.animation_manager.set_pet_image(self.pet_image)

        self.canvas.itemconfig(self.pet, image=self.tk_image)
        self.canvas.config(width=self.pet_image.width, height=self.pet_image.height)

        self.animation_manager.update_position_for_size_change(
            old_width, old_height,
            self.pet_image.width, self.pet_image.height
        )

        if self.animation_manager.is_docked_to_taskbar():
            self.update_docked_position()

        self.save_config()

    def adjust_speed(self, delta):
        self.animation_manager.adjust_speed(delta)
        self.save_config()
        self.update_context_menu()

    def reset_speed(self):
        self.animation_manager.reset_speed()
        self.save_config()
        self.update_context_menu()

    def adjust_size(self, delta):
        old_width = self.pet_image.width
        old_height = self.pet_image.height

        self.size_factor += delta
        self.size_factor = max(0.5, min(self.size_factor, 2.0))

        self.load_pet_image()
        self.animation_manager.set_pet_image(self.pet_image)

        self.canvas.itemconfig(self.pet, image=self.tk_image)
        self.canvas.config(width=self.pet_image.width, height=self.pet_image.height)

        self.animation_manager.update_position_for_size_change(
            old_width, old_height,
            self.pet_image.width, self.pet_image.height
        )

        if self.animation_manager.is_docked_to_taskbar():
            self.update_docked_position()

        self.save_config()
        self.update_context_menu()

    def reset_size(self):
        self.size_factor = 1.0
        self.adjust_size(0)

    def check_updates_ui(self):
        self.update_manager.check_updates_ui(self.quit_app)

    def show_suggestion_dialog(self):
        self.discord_integration.show_suggestion_dialog()

    def toggle_music(self):
        self.music_manager.toggle_music()

    def toggle_music_pause(self):
        self.music_manager.toggle_music_pause()

    def change_loop_mode(self):
        self.music_manager.change_loop_mode()

    def toggle_custom_playlist(self):
        self.music_manager.toggle_custom_playlist()

    def adjust_volume(self, delta):
        self.music_manager.adjust_volume(delta)

    def prev_song(self):
        self.music_manager.prev_song()

    def play_next_song(self):
        self.music_manager.play_next_song()

    def open_custom_playlist_editor(self):
        editor = Toplevel(self.root)
        editor.title("🎵 Editor de Lista Personal")
        editor.geometry("600x400")
        editor.attributes('-topmost', True)

        main_frame = Frame(editor)
        main_frame.pack(fill="both", expand=True, padx=10, pady=10)

        Label(main_frame, text="🎶 Selecciona canciones para tu lista personal:").pack(pady=5)

        all_songs = self.music_manager.get_all_songs()

        frame = Frame(main_frame)
        frame.pack(fill="both", expand=True)

        scrollbar = Scrollbar(frame)
        scrollbar.pack(side="right", fill="y")

        song_list = Listbox(frame, selectmode=MULTIPLE, yscrollcommand=scrollbar.set, width=80)
        song_list.pack(side="left", fill="both", expand=True)
        scrollbar.config(command=song_list.yview)

        music_dir = os.path.join(self.get_base_path(), "musica")
        for song in all_songs:
            rel_path = os.path.relpath(song, music_dir)
            song_list.insert(END, rel_path)
            song_list.itemconfig(END, {'bg': 'light yellow' if song in self.music_manager.custom_playlist else 'white'})

        for i, song in enumerate(all_songs):
            if song in self.music_manager.custom_playlist:
                song_list.selection_set(i)

        button_frame = Frame(main_frame)
        button_frame.pack(pady=10)

        def save_playlist():
            selected_indices = song_list.curselection()
            new_playlist = [all_songs[i] for i in selected_indices]
            self.music_manager.update_custom_playlist(new_playlist)
            editor.destroy()
            self.update_context_menu()

        Button(button_frame, text="💾 Guardar", command=save_playlist).pack(side="left", padx=5)
        Button(button_frame, text="❌ Cancelar", command=editor.destroy).pack(side="left", padx=5)

    def open_random_file(self, event):
        self.file_manager.open_random_file()

    def minimize_to_tray(self):
        self.system_integration.minimize_to_tray()

    def save_config(self):
        self.config_manager.set("size_factor", self.size_factor)
        x, y = self.animation_manager.get_position()
        self.config_manager.set("x", x)
        self.config_manager.set("y", y)

        self.music_manager.save_settings_to_config()
        self.animation_manager.save_settings_to_config()
        self.system_integration.save_settings_to_config()
        self.file_manager.save_settings_to_config()

        self.config_manager.save_config()

    def quit_app(self, icon=None, item=None):
        self.save_config()
        self.file_manager.cancel_auto_open_timer(self.root)
        self.music_manager.quit()
        self.system_integration.quit_app(icon, item)


if __name__ == "__main__":
    root = tk.Tk()
    root.config(bg='white')
    pet = InaPet(root)
    root.mainloop()